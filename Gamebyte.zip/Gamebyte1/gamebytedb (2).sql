-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 28, 2025 at 06:03 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gamebytedb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `admin_username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_username`, `email`, `password`) VALUES
(1, 'admin', 'admin@gmail.com', '$2y$10$oaOAzCE.92DZsXM4lu6ht.4xo5UoFZW3qh2xw0OqVDDLTwwBwQh7m'),
(2, 'admin2', 'admin2@gmail.com', '$2y$10$Ui.XRIHz8XLKhqkESQ8MY.3OoXVXFihJsxzkXTfaxzEibXX7kb3Xy');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `category_name`) VALUES
(12, 'Gaming Phones 2'),
(2, 'Headphones'),
(8, 'PC1'),
(3, 'PS5'),
(4, 'Xbox Series X');

-- --------------------------------------------------------

--
-- Table structure for table `chatbot_responses`
--

CREATE TABLE `chatbot_responses` (
  `id` int(11) NOT NULL,
  `question` varchar(255) NOT NULL,
  `answer` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `chatbot_responses`
--

INSERT INTO `chatbot_responses` (`id`, `question`, `answer`, `created_at`) VALUES
(1, 'What is your name?', 'I am your friendly chatbot!', '2025-04-23 04:30:36'),
(2, 'What are your hours?', 'I am available 24/7 to assist you!', '2025-04-23 04:30:36'),
(3, 'hello', 'Hey there! Welcome to our GameByte Store 🎮', '2025-04-25 13:17:40'),
(9, 'Do you sell gaming consoles?', 'Yes! We offer a range of consoles like PlayStation, Xbox, and Nintendo Switch.', '2025-04-27 13:19:02'),
(10, 'How can I track my order?', 'After placing an order, you will receive a tracking number via email.', '2025-04-27 13:19:02'),
(11, 'What payment methods do you accept?', 'We accept credit cards, PayPal, and cash on delivery.', '2025-04-27 13:19:02'),
(12, 'Can I return a product?', 'Of course! Please check our return policy page for detailed information.', '2025-04-27 13:19:02'),
(13, 'Do you offer discounts?', 'We regularly have promotions! Keep an eye on our website or subscribe to our newsletter.', '2025-04-27 13:19:02'),
(14, 'How long does delivery take?', 'Delivery usually takes between 3 to 5 business days depending on your location.', '2025-04-27 13:19:02'),
(15, 'Is there a warranty on products?', 'Yes, most of our products come with a one-year warranty. Check product details for specifics.', '2025-04-27 13:19:02'),
(16, 'Where is your store located?', 'We are based in Beirut, Lebanon! You can also shop online anytime.', '2025-04-27 13:19:02'),
(17, 'Can I pre-order upcoming games?', 'Absolutely! Pre-orders are available for selected titles. Visit the pre-order section.', '2025-04-27 13:19:02'),
(18, 'Do you have customer support?', 'Yes! You can reach us through the About Us page.', '2025-04-27 13:19:02'),
(19, 'What games are trending right now?', 'Check out our Trending Games section for the latest hits everyone is playing!', '2025-04-27 13:21:12'),
(20, 'Do you have gift cards?', 'Yes! We offer digital and physical gift cards. Perfect for any gamer.', '2025-04-27 13:21:12'),
(21, 'Can I change my order after placing it?', 'If your order hasn’t shipped yet, we can help you update it. Contact support quickly!', '2025-04-27 13:21:12'),
(22, 'Do you sell used games?', 'Yes, we offer both new and pre-owned games at great prices.', '2025-04-27 13:21:12'),
(23, 'Is there a loyalty program?', 'Stay tuned! We’re working on an awesome rewards program for our customers.', '2025-04-27 13:21:12'),
(24, 'How do I create an account?', 'Click the Sign Up button on our website and follow the easy steps.', '2025-04-27 13:21:12'),
(25, 'My payment failed. What should I do?', 'Please double-check your card details or try another payment method. Contact support if the issue continues.', '2025-04-27 13:21:12'),
(26, 'Can I cancel my order?', 'If your order hasn’t been processed yet, you can request a cancellation by contacting us.', '2025-04-27 13:21:12'),
(27, 'What if I receive a damaged item?', 'No worries! Contact us within 48 hours and we’ll arrange a replacement or refund.', '2025-04-27 13:21:12'),
(28, 'Do you offer free shipping?', 'Yes! Orders above $100 qualify for free standard shipping.', '2025-04-27 13:21:12');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customer_id` int(11) NOT NULL,
  `customer_username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_id`, `customer_username`, `email`, `password`, `phone`, `address`) VALUES
(9, 'hydar', 'hydar@gmail.com', '$2y$10$EZ2FOwurYp/ykysz6aAN6Oul4gneHlHAbB91rF.0c3g17V6LFa62.', NULL, NULL),
(10, 'Haydarthe5', 'haydarthe5@gmail.com', '$2y$10$onmpmUdqy1UDbUaHWEf.7.S6PCpBzSeu6MYmuF7pBjUZIbE77EwI.', NULL, NULL),
(11, 'haydar', 'haydar@gmail.com', '$2y$10$n6ib9FnzY6NWs23H14w6y.kWSbtnIBIqZ4pDoS1NZ8BAHmfw/BUGW', NULL, NULL),
(12, '12345', 'hydar123@gmail.com', '$2y$10$aWXX.LNsRhu10t1o1U9mZOBUTjRxJFXBVkUqcl.ZO2o65dr/oTFJS', NULL, NULL),
(13, 'ssdsds', 'Haydadwdwr@gmail.com', '$2y$10$fNw9hgwQf9CCaXVW0SOu9ecZ0II5sffAvQcPgHAB4eQD.g4fhgK0m', NULL, NULL),
(14, 'gamebyte', 'gamebyteHH@gmail.com', '$2y$10$OxpBFQJIFYxZJo/EThoucuZYHNWd38RPGSZOhfGQmCax/Aj4wzb.K', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `shipping_address` varchar(255) NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  `payment_method` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `order_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` varchar(50) DEFAULT 'pending',
  `tracking_id` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `customer_id`, `total_price`, `shipping_address`, `phone_number`, `payment_method`, `created_at`, `order_date`, `status`, `tracking_id`) VALUES
(5, 11, 40.00, 'Beirut', '96178848224', 'cash_on_delivery', '2025-04-26 14:17:58', '2025-04-26 14:17:58', 'delivered', NULL),
(6, 11, 40.00, 'Beirut', '96178848224', 'cash_on_delivery', '2025-04-26 14:56:58', '2025-04-26 14:56:58', 'pending', NULL),
(7, 11, 40.00, 'Beirut', '96178848224', 'visa_card', '2025-04-26 16:54:09', '2025-04-26 16:54:09', 'pending', NULL),
(8, 11, 135.00, 'Beirut', '96178848224', 'cash_on_delivery', '2025-04-26 17:21:30', '2025-04-26 17:21:30', 'cancelled', NULL),
(9, 11, 180.00, 'Beirut', '96178848224', 'cash_on_delivery', '2025-04-26 22:22:24', '2025-04-26 22:22:24', 'cancelled', NULL),
(10, 11, 45.00, 'Beirut', '96178848224', 'cash_on_delivery', '2025-04-27 05:46:59', '2025-04-27 05:46:59', 'pending', 'TRK680DC4D3EF75F'),
(11, 14, 45.00, 'Beirut', '96178848224', 'cash_on_delivery', '2025-04-27 05:48:52', '2025-04-27 05:48:52', 'cancelled', 'TRK680DC544CB2F1'),
(12, 14, 45.00, 'Beirut', '96178848224', 'cash_on_delivery', '2025-04-27 06:11:18', '2025-04-27 06:11:18', 'cancelled', NULL),
(13, 11, 45.00, 'Beirut', '96178848224', 'cash_on_delivery', '2025-04-28 06:10:40', '2025-04-28 06:10:40', 'delivering', NULL),
(14, 11, 385.00, 'Beirut', '96178848224', 'cash_on_delivery', '2025-04-28 08:02:06', '2025-04-28 08:02:06', 'delivered', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `order_item_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`order_item_id`, `order_id`, `product_id`, `quantity`) VALUES
(12, 13, 23, 1),
(13, 14, 25, 11);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `price` decimal(10,0) NOT NULL,
  `category_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 0,
  `subcategory_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_name`, `description`, `image`, `price`, `category_id`, `quantity`, `subcategory_id`) VALUES
(21, 'Spiderman 2 PS5 2', 'Swing through Marvel’s New York like never before with Spider-Man for PlayStation 5. Experience stunning visuals, lightning-fast load times, and immersive gameplay as you join Peter Parker and Miles Morales in thrilling adventures. A must-have for action ', 'uploads/1745745377_1745687053_spiderman2.jpg', 45, 3, 50, 3),
(23, 'Dragon Ball Sparking Zero', 'Dragon Ball: Sparking! ZERO brings the legendary Budokai Tenkaichi series back with stunning graphics, intense battles, and the largest character roster yet. Relive epic moments and unleash ultimate power in explosive 3D fights.', 'uploads/1745764105_dbsz.jpg', 45, 3, 100, 3),
(24, 'Forza Horizon', 'Forza Horizon is an open-world racing adventure featuring stunning visuals, a massive car roster, and dynamic seasons. Race, explore, and experience ultimate driving freedom across breathtaking landscapes.', 'uploads/1745764189_forza.jpg', 30, 4, 100, 2),
(25, 'FC 25', 'EA Sports FC 25 delivers the next evolution of football gaming with realistic gameplay, updated teams, and new features that bring every match to life. Build your dream squad and dominate the pitch!', 'uploads/1745764284_fc25.jpg', 35, 3, 83, 3),
(26, 'God Of War Ragnarok', 'God of War Ragnarök is an epic action-adventure where Kratos and Atreus face the end of the Norse world. Experience breathtaking battles, emotional storytelling, and stunning realms in this award-winning sequel.', 'uploads/1745764447_gow2.jpg', 35, 3, 50, 3),
(27, 'The Last Of Us Part 1', 'The Last of Us Part I is a stunning remake of the iconic story, featuring enhanced visuals, modernized gameplay, and unforgettable emotional storytelling. Experience Joel and Ellie’s journey like never before.', 'uploads/1745764555_tlou.jpg', 50, 3, 100, 3),
(29, 'PS5 Pro', 'The PS5 Pro is the ultimate gaming console designed to elevate your gaming experience. With enhanced performance, faster load times, and stunning 4K graphics, it offers a smoother, more immersive gameplay experience.', 'uploads/1745851153_pro_680769f371d70.jfif', 750, 3, 10, 5),
(30, 'PS5 Console', 'The PS5 Console is a cutting-edge gaming system that brings your gaming experience to life with incredible power, speed, and performance. Featuring a custom SSD with an ultra-fast load time of up to 825GB of storage, the PS5 allows you to jump into your f', 'uploads/1745851357_51oLSJq1WrL.jpg', 450, 3, 15, 5),
(31, 'PS5 Console 30 Years Anniversary Edition', 'Celebrate 30 years of PlayStation with the PS5 30th Anniversary Edition, a special edition that combines the power of next-gen gaming with a nostalgic design.', 'uploads/1745851623_playstation-5-pro-console-30th-anniversary-limited-edition-b_9jyg.jpg', 550, 3, 15, 5),
(32, 'PS5 Console Spiderman edition with Spiderman 2 Game', 'The PS5 Spider-Man Edition brings the world of Marvel\\\'s iconic hero into your gaming setup. Featuring a sleek, Spider-Man-inspired design, this limited-edition console stands out with its striking colors and unique artwork.', 'uploads/1745851786_images.jfif', 650, 3, 5, 5),
(33, 'Xbox Series X Console', 'The Xbox Series X is the most powerful console from Microsoft, designed to deliver an ultra-fast, immersive gaming experience. Equipped with a custom 1TB SSD, it ensures near-instant load times and smooth transitions between games.', 'uploads/1745852097_xbox-x-feature.jpg', 350, 4, 20, 6),
(34, 'Xbox Series S Console', 'The Xbox Series S is the compact and affordable next-gen console that packs a punch. With a custom 512GB SSD, it delivers fast load times and seamless gameplay, ensuring you can jump straight into your favorite games.', 'uploads/1745852332_XboxSeriesS_HERO.jpg', 250, 4, 20, 6),
(35, 'Xbox Series X Console HALO edition', 'The Xbox Series X Halo Edition is a special, limited-edition console that brings the legendary Halo universe to life with stunning design and unmatched performance. Featuring a unique, Halo-inspired design with custom artwork, this console celebrates the ', 'uploads/1745852564_Halo_gamescom_HEROFINAL.jpg', 450, 4, 10, 6),
(36, 'DualSense Cobalt Blue Wireless Controller', 'The DualSense Cobalt Blue Wireless Controller for PlayStation 5 offers an enhanced gaming experience with its sleek, vibrant design and next-gen features.', 'uploads/1745852732_Blue-website-1-2.jpg', 65, 3, 15, 7),
(37, 'DualSense Volcanic Red Wireless Controller', 'The DualSense Volcanic Red Wireless Controller brings a bold, fiery look to your PlayStation 5 setup with its vibrant red design', 'uploads/1745852845_red-website-controller-2.jpg', 70, 3, 20, 7),
(38, 'DualSense Gray Camouflage Wireless Controller', 'The DualSense Gray Camouflage Wireless Controller combines a rugged, military-inspired design with advanced features to enhance your PlayStation 5 experience. ', 'uploads/1745852920_C6D91804-70EA-42E4-90F8-C0DA43AAEE0B.png', 70, 3, 20, 7);

-- --------------------------------------------------------

--
-- Table structure for table `subcategory`
--

CREATE TABLE `subcategory` (
  `subcategory_id` int(11) NOT NULL,
  `subcategory_name` varchar(255) NOT NULL,
  `category_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subcategory`
--

INSERT INTO `subcategory` (`subcategory_id`, `subcategory_name`, `category_id`) VALUES
(3, 'PS5 Games', 3),
(4, 'Xbox Games', 4),
(5, 'PS5 Consoles', 3),
(6, 'Xbox Consoles', 4),
(7, 'PS5 Controllers', 3),
(8, 'Xbox Series X Controllers', 4);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `customer_id` (`customer_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_id`),
  ADD UNIQUE KEY `category_name` (`category_name`);

--
-- Indexes for table `chatbot_responses`
--
ALTER TABLE `chatbot_responses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `customer_id` (`customer_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`order_item_id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `subcategory`
--
ALTER TABLE `subcategory`
  ADD PRIMARY KEY (`subcategory_id`),
  ADD KEY `category_id` (`category_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `chatbot_responses`
--
ALTER TABLE `chatbot_responses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `order_item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `subcategory`
--
ALTER TABLE `subcategory`
  MODIFY `subcategory_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`),
  ADD CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`);

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`);

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`),
  ADD CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`);

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `category` (`category_id`);

--
-- Constraints for table `subcategory`
--
ALTER TABLE `subcategory`
  ADD CONSTRAINT `subcategory_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `category` (`category_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
