<?php
include('condb.php');

$search = '';

if (isset($_GET['query'])) {
    $search = trim($_GET['query']);
    $sql = "SELECT product_id, product_name, image FROM products WHERE product_name LIKE '%$search%' LIMIT 5";
    $result = $conn->query($sql);

    $products = [];

    while ($row = $result->fetch_assoc()) {
        $products[] = $row;
    }

    echo json_encode($products);
}
?>
