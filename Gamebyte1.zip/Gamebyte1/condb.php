<?php
$servername = "localhost";
$username = "root";
$password = "";
$gamebytedb = "gamebytedb";

$conn = mysqli_connect($servername, $username, $password, $gamebytedb);

if (!$conn) {
    die("Connection failed : " . mysqli_connect_error());
}

?>