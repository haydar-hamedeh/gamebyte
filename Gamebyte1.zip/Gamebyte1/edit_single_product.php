<?php
session_start();
include('condb.php');

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: admin_login.php');
    exit();
}

// Check if product_id is passed
if (!isset($_GET['product_id'])) {
    $_SESSION['error'] = "No product selected!";
    header('Location: edit_product.php');
    exit();
}

$product_id = $_GET['product_id'];

// Fetch product details
$product_sql = "SELECT * FROM products WHERE product_id = '$product_id'";
$product_result = $conn->query($product_sql);

if ($product_result->num_rows == 0) {
    $_SESSION['error'] = "Product not found!";
    header('Location: edit_product.php');
    exit();
}

$product = $product_result->fetch_assoc();

// Fetch categories and subcategories for dropdown
$categories_result = $conn->query("SELECT * FROM category");
$subcategories_result = $conn->query("SELECT * FROM subcategory");

// Handle update
$update_success = false;
if (isset($_POST['update_product'])) {
    $product_name = trim($_POST['product_name']);
    $price = floatval($_POST['price']);
    $category_id = intval($_POST['category_id']);
    $subcategory_id = intval($_POST['subcategory_id']);
    $current_image = $_POST['current_image'];
    
    // Handle image upload
    if (!empty($_FILES['image']['name'])) {
        $image_name = 'uploads/' . basename($_FILES['image']['name']);
        move_uploaded_file($_FILES['image']['tmp_name'], $image_name);

        // Delete old image
        if (file_exists($current_image)) {
            unlink($current_image);
        }
    } else {
        $image_name = $current_image; // No new image uploaded
    }

    // Update query
    $update_sql = "UPDATE products SET 
                    product_name = '$product_name', 
                    price = '$price', 
                    category_id = '$category_id',
                    subcategory_id = '$subcategory_id',
                    image = '$image_name'
                   WHERE product_id = '$product_id'";

if ($conn->query($update_sql) === TRUE) {
    $update_success = true;

  
} else {
    $_SESSION['error'] = "Error updating product: " . $conn->error;
}
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Product</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body class="bg-gray-800 text-white min-h-screen">
    <?php include('admin_navbar.php'); ?>

    <div class="container mx-auto p-8">
        <h1 class="text-3xl font-semibold mb-6">Edit Product</h1>

        <form action="" method="POST" enctype="multipart/form-data" class="bg-gray-700 p-8 rounded-lg shadow-lg space-y-6">
            <div>
                <label class="block mb-2">Product Name</label>
                <input type="text" name="product_name" value="<?php echo htmlspecialchars($product['product_name']); ?>"
                       class="w-full p-2 rounded bg-gray-600 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500" required>
            </div>

            <div>
                <label class="block mb-2">Price</label>
                <input type="number" name="price" step="0.01" value="<?php echo htmlspecialchars($product['price']); ?>"
                       class="w-full p-2 rounded bg-gray-600 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500" required>
            </div>

            <div>
                <label class="block mb-2">Category</label>
                <select name="category_id" class="w-full p-2 rounded bg-gray-600 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500" required>
                    <?php
                    while ($category = $categories_result->fetch_assoc()) {
                        $selected = ($product['category_id'] == $category['category_id']) ? 'selected' : '';
                        echo "<option value='{$category['category_id']}' $selected>" . htmlspecialchars($category['category_name']) . "</option>";
                    }
                    ?>
                </select>
            </div>

            <div>
                <label class="block mb-2">Subcategory</label>
                <select name="subcategory_id" class="w-full p-2 rounded bg-gray-600 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500" required>
                    <?php
                    while ($subcategory = $subcategories_result->fetch_assoc()) {
                        $selected = (isset($product['subcategory_id']) && $product['subcategory_id'] == $subcategory['subcategory_id']) ? 'selected' : '';
                        echo "<option value='{$subcategory['subcategory_id']}' $selected>" . htmlspecialchars($subcategory['subcategory_name']) . "</option>";
                    }
                    ?>
                </select>
            </div>

            <div>
                <label class="block mb-2">Current Image</label>
                <img src="<?php echo htmlspecialchars($product['image']); ?>" alt="Product Image" class="w-32 mb-4">
                <input type="file" name="image" class="block">
                <input type="hidden" name="current_image" value="<?php echo htmlspecialchars($product['image']); ?>">
            </div>

            <div>
                <button type="submit" name="update_product"
                        class="bg-indigo-500 px-6 py-2 rounded hover:bg-indigo-600 transition text-white font-semibold">
                    Update Product
                </button>
            </div>
        </form>
    </div>

    <!-- Instant SweetAlert2 popup if updated -->
    <?php if ($update_success): ?>
    <script>
      Swal.fire({
        icon: 'success',
        title: 'Updated!',
        text: 'Product updated successfully!',
        confirmButtonColor: '#6366F1'
      }).then((result) => {
          if (result.isConfirmed) {
              window.location.href = "edit_product.php"; // Redirect after OK
          }
      });
    </script>
    <?php endif; ?>

    <?php if (isset($_SESSION['error'])): ?>
    <script>
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: '<?php echo $_SESSION['error']; ?>',
        confirmButtonColor: '#EF4444'
      });
    </script>
    <?php unset($_SESSION['error']); endif; ?>

</body>
</html>
