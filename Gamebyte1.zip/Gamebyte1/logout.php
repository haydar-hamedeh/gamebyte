<?php
session_start();
include('condb.php');

// Check if user and cart exist before logout
if (isset($_SESSION['customer_id']) && isset($_SESSION['cart'])) {
    $customer_id = $_SESSION['customer_id'];
    $cart = $_SESSION['cart'];

    // Remove previous cart for this customer (to avoid duplicates)
    $conn->query("DELETE FROM cart_items WHERE customer_id = $customer_id");

    // Insert current session cart items into database
    foreach ($cart as $product_id => $item) {
        $quantity = $item['quantity'];

        $stmt = $conn->prepare("INSERT INTO cart_items (customer_id, product_id, quantity) VALUES (?, ?, ?)");
        $stmt->bind_param("iii", $customer_id, $product_id, $quantity);
        $stmt->execute();
        $stmt->close();
    }
}

// Clean up session
session_unset();
session_destroy();

// Redirect to home
header("Location: index.php");
exit();
?>
