<?php
include('condb.php');
session_start();

if (!isset($_GET['id'])) {
    header('Location: index.php');
    exit();
}

$product_id = intval($_GET['id']);
$sql = "SELECT * FROM products WHERE product_id = $product_id";
$result = $conn->query($sql);

if ($result->num_rows == 0) {
    echo "<h1 class='text-white text-center mt-10'>Product not found!</h1>";
    exit();
}

$product = $result->fetch_assoc();

// Handle Add to Cart
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['quantity'])) {
    // Check if user is logged in
    if (!isset($_SESSION['customer_id'])) {
        header('Location: login.php');
        exit();
    }

    $quantity = intval($_POST['quantity']);

    if ($quantity > 0 && $quantity <= $product['quantity']) {
        $_SESSION['cart'][$product_id] = [
            'product_id' => $product['product_id'],
            'product_name' => $product['product_name'],
            'price' => $product['price'],
            'image' => $product['image'],
            'quantity' => $quantity
        ];
        header('Location: cart.php');
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title><?php echo htmlspecialchars($product['product_name']); ?> - Gamebyte Store</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gradient-to-b from-black via-gray-800 to-gray-900 text-white font-sans">

<!-- Navbar -->
<?php include('navbar.php'); ?>

<!-- Product Details Section -->
<div class="max-w-7xl mx-auto px-6 py-20 grid grid-cols-1 md:grid-cols-2 gap-10 animate-fadeIn">

  <!-- Product Image -->
  <div class="flex justify-center">
    <img src="<?php echo htmlspecialchars($product['image']); ?>" alt="<?php echo htmlspecialchars($product['product_name']); ?>" class="w-96 h-auto rounded-lg shadow-lg object-cover">
  </div>

  <!-- Product Info -->
  <div class="flex flex-col justify-center">
    <h1 class="text-4xl font-bold mb-4"><?php echo htmlspecialchars($product['product_name']); ?></h1>
    <p class="text-2xl text-green-400 mb-6">$<?php echo htmlspecialchars($product['price']); ?></p>

    <div class="flex items-center mb-6">
      <span class="text-gray-300 mr-2">Quantity:</span>
      <span class="text-white font-semibold"><?php echo htmlspecialchars($product['quantity']); ?></span>
    </div>

    <?php if (isset($_SESSION['customer_id'])) { ?>
    <!-- Form only if logged in -->
    <div class="flex space-x-4">
  <div class="flex items-center border border-gray-600 rounded-lg overflow-hidden">
    <button type="button" id="decrement" class="px-4 py-2 bg-gray-700 hover:bg-gray-600">-</button>
    <input type="text" id="quantity" value="1" readonly class="w-12 text-center bg-gray-800 border-none outline-none text-white">
    <button type="button" id="increment" class="px-4 py-2 bg-gray-700 hover:bg-gray-600">+</button>
  </div>
  <button 
    type="button" 
    id="addToCartBtn"
    class="bg-purple-600 hover:bg-purple-700 px-6 py-3 rounded-full font-bold transition duration-300"
    data-product-id="<?php echo $product['product_id']; ?>"
  >
    Add to Cart
  </button>
</div>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
document.getElementById('addToCartBtn')?.addEventListener('click', () => {
  const productId = document.getElementById('addToCartBtn').getAttribute('data-product-id');
  const quantity = parseInt(document.getElementById('quantity').value);

  fetch('add_to_cart.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ product_id: productId, quantity: quantity })
  })
  .then(res => res.json())
  .then(data => {
    if (data.success) {
      Swal.fire({
        title: 'Product Added!',
        text: `${data.product_name} (x${quantity}) has been added to your cart.`,
        icon: 'success',
        confirmButtonText: 'OK'
      });
    } else {
      Swal.fire({
        title: 'Oops!',
        text: data.message || 'Failed to add to cart.',
        icon: 'error',
        confirmButtonText: 'Try Again'
      });
    }
  })
  .catch(err => {
    Swal.fire({
      title: 'Error!',
      text: 'An error occurred while adding the product.',
      icon: 'error',
      confirmButtonText: 'OK'
    });
  });
});
</script>


    <?php } else { ?>
    <!-- Show login button if not logged in -->
    <a href="login.php" class="mt-4 bg-red-500 hover:bg-red-600 px-6 py-3 rounded-full font-bold text-center transition duration-300 inline-block">
      Login to Add to Cart
    </a>
    <?php } ?>

    <div class="flex items-center mt-6 space-x-4 text-gray-400">
      <span>Category:</span>
      <span>PS5 Games</span>
    </div>

    <div class="flex items-center mt-4 space-x-4">
      <a href="#" class="text-gray-400 hover:text-white">❤️ Add to Wishlist</a>
    </div>

  </div>
</div>

<!-- Footer -->
<footer class="bg-gray-800 text-center py-10 text-gray-400 text-sm mt-20">
    &copy; <?php echo date('Y'); ?> Gamebyte Store. All rights reserved.
</footer>

<!-- JavaScript for Increment/Decrement -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const incrementBtn = document.getElementById('increment');
    const decrementBtn = document.getElementById('decrement');
    const quantityInput = document.getElementById('quantity');
    const maxQuantity = <?php echo $product['quantity']; ?>;

    incrementBtn.addEventListener('click', function() {
        let current = parseInt(quantityInput.value);
        if (current < maxQuantity) {
            quantityInput.value = current + 1;
        }
    });

    decrementBtn.addEventListener('click', function() {
        let current = parseInt(quantityInput.value);
        if (current > 1) {
            quantityInput.value = current - 1;
        }
    });
});
</script>

</body>
</html>
