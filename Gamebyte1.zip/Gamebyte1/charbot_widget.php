<!-- Floating Chatbot Button -->
<div id="chatbot-toggle" style="position: fixed; bottom: 30px; right: 30px; background-color: #3b78e6; color: white; border: none; border-radius: 50%; width: 60px; height: 60px; font-size: 24px; display: flex; justify-content: center; align-items: center; cursor: pointer; z-index: 9999;">
  💬
</div>

<!-- Chatbot Window -->
<div id="chatbot-window" style="display: none; position: fixed; bottom: 100px; right: 30px; width: 320px; height: 400px; background: #fff; border-radius: 15px; box-shadow: 0 4px 15px rgba(0,0,0,0.3); z-index: 9999; flex-direction: column; overflow: hidden; transition: all 0.3s ease;">
  <div style="background-color: #3b78e6; color: white; padding: 12px; font-weight: bold; text-align: center; font-size: 18px; border-top-left-radius: 15px; border-top-right-radius: 15px;">GameByte Chatbot</div>
  <div id="chat-content" style="flex: 1; padding: 10px; overflow-y: auto; font-size: 14px; display: flex; flex-direction: column; gap: 10px;"></div>
  <div style="padding: 10px; border-top: 1px solid #ddd; background: #f9f9f9;">
    <input type="text" id="user-message" placeholder="Type a message..." style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 10px; font-size: 14px; outline: none; background: white; color: black;">
  </div>
</div>

<!-- Chatbot Script -->
<script>
const toggleBtn = document.getElementById('chatbot-toggle');
const chatWindow = document.getElementById('chatbot-window');
const userInput = document.getElementById('user-message');
const chatContent = document.getElementById('chat-content');

toggleBtn.addEventListener('click', () => {
  chatWindow.style.display = (chatWindow.style.display === 'flex') ? 'none' : 'flex';
});

userInput.addEventListener('keypress', function(e) {
  if (e.key === 'Enter' && userInput.value.trim() !== '') {
    const userMsg = userInput.value.trim();
    displayMessage(userMsg, 'user');
    userInput.value = '';

    fetch('/GameByte1/chatbot.php', { // << Absolute path correction here
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: userMsg })
    })
    .then(response => response.json())
    .then(data => {
      const botReply = data.reply;
      displayMessage(botReply, 'bot');
    })
    .catch(error => {
      console.error('Error:', error);
      displayMessage('Sorry, something went wrong.', 'bot');
    });
  }
});

function displayMessage(message, sender) {
  const messageDiv = document.createElement('div');
  messageDiv.classList.add('message');
  messageDiv.classList.add(sender === 'user' ? 'user-message' : 'bot-message');
  messageDiv.innerText = message;
  chatContent.appendChild(messageDiv);
  chatContent.scrollTop = chatContent.scrollHeight;
}
</script>

<!-- Chatbot Styles -->
<style>
.message {
  max-width: 70%;
  padding: 8px 12px;
  border-radius: 20px;
  animation: fadeIn 0.5s;
}
.user-message {
  background-color: #3b78e6;
  color: white;
  align-self: flex-end;
  text-align: right;
}
.bot-message {
  background-color: #f1f0f0;
  color: black;
  align-self: flex-start;
  text-align: left;
}
@keyframes fadeIn {
  from { opacity: 0; transform: translateY(10px); }
  to { opacity: 1; transform: translateY(0); }
}
#user-message:focus {
  border-color: #3b78e6;
}
</style>
