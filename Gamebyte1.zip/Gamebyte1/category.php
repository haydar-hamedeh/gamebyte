<?php
include('condb.php');
session_start();

// Get the category ID from the query parameter safely
$category_id = isset($_GET['category_id']) ? intval($_GET['category_id']) : 0;
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Category Products</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gradient-to-b from-black via-gray-800 to-gray-900 text-white font-sans">
  <?php include('navbar.php'); ?>

  <section id="category-heading" class="py-20 text-center">
    <h2 class="text-5xl font-extrabold text-white mb-10">Products in Selected Category</h2>
  </section>

  <section id="category-products" class="py-20 px-4">
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-12">
      <?php
      if ($category_id > 0) {
          // Fetch products based on category
          $stmt = $conn->prepare("SELECT * FROM products WHERE category_id = ?");
          $stmt->bind_param("i", $category_id);
          $stmt->execute();
          $result = $stmt->get_result();

          if ($result->num_rows > 0) {
              while ($row = $result->fetch_assoc()) {
                  echo "<div class='bg-gray-800 p-6 rounded-lg text-center shadow-xl'>";
                  echo "<img src='" . htmlspecialchars($row['image']) . "' alt='" . htmlspecialchars($row['product_name']) . "' class='w-full h-48 object-cover mb-6'>";
                  echo "<h3 class='text-2xl text-white mb-3'>" . htmlspecialchars($row['product_name']) . "</h3>";
                  echo "<p class='text-sm text-gray-400 mb-4'>" . htmlspecialchars($row['description']) . "</p>";
                  echo "<p class='text-lg text-gray-500 mb-4'>Quantity: " . htmlspecialchars($row['quantity']) . "</p>";
                  echo "<p class='text-lg text-gray-500 mb-4'>Price: $" . htmlspecialchars($row['price']) . "</p>";

                  // View Details Button
                  echo "<a href='product.php?product_id=" . urlencode($row['product_id']) . "' class='block mt-4 bg-gradient-to-r from-green-400 to-blue-500 text-white hover:bg-gradient-to-l px-4 py-2 rounded-full text-sm font-semibold transition-all duration-300'>View Details</a>";

                  // Add to Cart / Login Button
                  if (isset($_SESSION['customer_id'])) {
                      echo "<a href='add_to_cart.php?product_id=" . urlencode($row['product_id']) . "' class='block mt-4 bg-gradient-to-r from-purple-500 to-indigo-500 text-white hover:bg-gradient-to-l px-4 py-2 rounded-full text-sm font-semibold transition-all duration-300'>Add to Cart</a>";
                  } else {
                      echo "<a href='login.php' class='block mt-4 bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-full text-sm font-semibold transition-all duration-300'>Login to Add to Cart</a>";
                  }
                  echo "</div>";
              }
          } else {
              echo "<p class='text-white text-center w-full'>No products available in this category.</p>";
          }
          $stmt->close();
      } else {
          echo "<p class='text-white text-center w-full'>No category selected.</p>";
      }
      ?>
    </div>
  </section>

  <!-- Chatbot Button and Window -->
  <div id="chatbot-toggle" style="position: fixed; bottom: 30px; right: 30px; background-color: #3b78e6; color: white; border: none; border-radius: 50%; width: 60px; height: 60px; font-size: 24px; display: flex; justify-content: center; align-items: center; cursor: pointer; z-index: 9999;">
    💬
  </div>

  <div id="chatbot-window" class="hidden chatbot-window-style">
    <div class="chatbot-header">GameByte Chatbot</div>
    <div id="chat-content" class="chatbot-content"></div>
    <div class="chatbot-input-area">
      <input type="text" id="user-message" placeholder="Type a message..." class="chatbot-input">
    </div>
  </div>

  <!-- Chatbot Script -->
  <script>
    const toggleBtn = document.getElementById('chatbot-toggle');
    const chatWindow = document.getElementById('chatbot-window');
    const userInput = document.getElementById('user-message');
    const chatContent = document.getElementById('chat-content');

    toggleBtn.addEventListener('click', () => {
      if (chatWindow.classList.contains('hidden')) {
        chatWindow.classList.remove('hidden');
        setTimeout(() => {
          chatWindow.style.transform = 'scale(1)';
          chatWindow.style.opacity = '1';
        }, 10);
      } else {
        chatWindow.style.transform = 'scale(0)';
        chatWindow.style.opacity = '0';
        setTimeout(() => {
          chatWindow.classList.add('hidden');
        }, 300);
      }
    });

    userInput.addEventListener('keypress', function(e) {
      if (e.key === 'Enter' && userInput.value.trim() !== '') {
        const userMsg = userInput.value.trim();
        displayMessage(userMsg, 'user');
        userInput.value = '';

        fetch('/GameByte1/chatbot.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ message: userMsg })
        })
        .then(response => response.json())
        .then(data => {
          const botReply = data.reply;
          displayMessage(botReply, 'bot');
        })
        .catch(error => {
          console.error('Error:', error);
          displayMessage('Sorry, something went wrong.', 'bot');
        });
      }
    });

    function displayMessage(message, sender) {
      const messageDiv = document.createElement('div');
      messageDiv.classList.add('message');
      messageDiv.classList.add(sender === 'user' ? 'user-message' : 'bot-message');
      messageDiv.innerText = message;
      chatContent.appendChild(messageDiv);
      chatContent.scrollTop = chatContent.scrollHeight;
    }
  </script>

  <!-- Chatbot Styles -->
  <style>
    .chatbot-window-style {
      position: fixed;
      bottom: 100px;
      right: 30px;
      width: 320px;
      height: 400px;
      background: #fff;
      border-radius: 15px;
      box-shadow: 0 4px 15px rgba(0,0,0,0.3);
      z-index: 9999;
      flex-direction: column;
      overflow: hidden;
      transform: scale(0);
      opacity: 0;
      transition: all 0.3s ease;
      display: flex;
    }
    .chatbot-header {
      background-color: #3b78e6;
      color: white;
      padding: 12px;
      font-weight: bold;
      text-align: center;
      font-size: 18px;
      border-top-left-radius: 15px;
      border-top-right-radius: 15px;
    }
    .chatbot-content {
      flex: 1;
      padding: 10px;
      overflow-y: auto;
      font-size: 14px;
      display: flex;
      flex-direction: column;
      gap: 10px;
      background: #f9f9f9;
    }
    .chatbot-input-area {
      padding: 10px;
      border-top: 1px solid #ddd;
      background: #f1f0f0;
    }
    .chatbot-input {
      width: 100%;
      padding: 10px;
      border: 1px solid #ccc;
      border-radius: 10px;
      font-size: 14px;
      outline: none;
      background: white;
      color: black;
    }
    .chatbot-input:focus {
      border-color: #3b78e6;
    }
    .message {
      max-width: 70%;
      padding: 8px 12px;
      border-radius: 20px;
      animation: fadeIn 0.5s;
    }
    .user-message {
      background-color: #3b78e6;
      color: white;
      align-self: flex-end;
      text-align: right;
    }
    .bot-message {
      background-color: #e5e5ea;
      color: black;
      align-self: flex-start;
      text-align: left;
    }
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(10px); }
      to { opacity: 1; transform: translateY(0); }
    }
  </style>

</body>
</html>
