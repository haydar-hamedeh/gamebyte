<?php
include('condb.php');
session_start();

// Check if the user is logged in
if (!isset($_SESSION['customer_id'])) {
    header("Location: signup.php");
    exit();
}

// Validate input
if (isset($_POST['product_id']) && isset($_POST['quantity'])) {
    $product_id = intval($_POST['product_id']);
    $quantity = intval($_POST['quantity']);

    // Fetch the product's available stock
    $sql = "SELECT quantity FROM products WHERE product_id = $product_id";
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        $product = $result->fetch_assoc();
        $available_quantity = intval($product['quantity']);

        if ($quantity > 0 && $quantity <= $available_quantity) {
            if (isset($_SESSION['cart'][$product_id])) {
                $_SESSION['cart'][$product_id]['quantity'] = $quantity;
            }
            header("Location: cart.php");
            exit();
        } else {
            $_SESSION['cart_error'] = "You can only purchase up to $available_quantity units.";
            header("Location: cart.php");
            exit();
        }
    } else {
        $_SESSION['cart_error'] = "Product not found.";
        header("Location: cart.php");
        exit();
    }
} else {
    $_SESSION['cart_error'] = "Invalid cart update request.";
    header("Location: cart.php");
    exit();
}
?>
