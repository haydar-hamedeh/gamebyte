<?php
session_start();
include('condb.php');

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Validate password with regex (at least 1 uppercase, 1 lowercase, and 1 special character)
    if (!preg_match('/[A-Z]/', $password)) {
        $_SESSION['error'] = "Password must contain at least one uppercase letter.";
    } elseif (!preg_match('/[a-z]/', $password)) {
        $_SESSION['error'] = "Password must contain at least one lowercase letter.";
    } elseif (!preg_match('/[\W_]/', $password)) { // Matches special characters or symbols
        $_SESSION['error'] = "Password must contain at least one special character (e.g., @, $, !).";
    } else {
        // Encrypt the password using password_hash()
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Insert admin data into the database
        $sql = "INSERT INTO admin (admin_username, email, password) VALUES ('$username', '$email', '$hashed_password')";

        if ($conn->query($sql) === TRUE) {
            $_SESSION['message'] = "Admin account created successfully!";
            header("Location: admin_login.php");
            exit();
        } else {
            $_SESSION['error'] = "Error: " . $sql . "<br>" . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Sign Up</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.0.3/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-900 text-white font-sans">

<!-- Sign Up Form -->
<div class="max-w-sm mx-auto mt-20 bg-gray-800 p-6 rounded-lg shadow-lg">
    <h2 class="text-2xl font-bold text-center mb-6">Admin Sign Up</h2>

    <!-- Display success or error message -->
    <?php if (isset($_SESSION['error'])) { ?>
        <div class="bg-red-600 text-white p-4 rounded mb-6"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
    <?php } ?>
    <?php if (isset($_SESSION['message'])) { ?>
        <div class="bg-green-600 text-white p-4 rounded mb-6"><?php echo $_SESSION['message']; unset($_SESSION['message']); ?></div>
    <?php } ?>

    <form action="admin_signup.php" method="POST">
        <div class="mb-4">
            <label for="username" class="block text-lg">Username:</label>
            <input type="text" name="username" id="username" required 
                class="w-full p-3 rounded-md bg-gray-700 text-white border border-gray-600 focus:outline-none focus:border-purple-500" 
                placeholder="Enter username"
                value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>">
        </div>

        <div class="mb-4">
            <label for="email" class="block text-lg">Email:</label>
            <input type="email" name="email" id="email" required 
                class="w-full p-3 rounded-md bg-gray-700 text-white border border-gray-600 focus:outline-none focus:border-purple-500" 
                placeholder="Enter email"
                value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
        </div>
        
        <div class="mb-4">
            <label for="password" class="block text-lg">Password:</label>
            <input type="password" name="password" id="password" required 
                class="w-full p-3 rounded-md bg-gray-700 text-white border border-gray-600 focus:outline-none focus:border-purple-500" 
                placeholder="Enter password"
                value="">
            <small class="text-gray-400">Password must contain at least one uppercase letter, one lowercase letter, and one special character (e.g., @, $, !)</small>
        </div>
        
        <button type="submit" class="w-full bg-gradient-to-r from-purple-500 to-indigo-500 hover:bg-gradient-to-l px-6 py-3 rounded-full text-sm font-semibold transition-all duration-300">Sign Up</button>
    </form>

    <p class="mt-4 text-center">
        Already have an account? <a href="admin_login.php" class="text-purple-400 hover:text-purple-600">Login</a>
    </p>
</div>

</body>
</html>
