<?php
include('condb.php');
session_start();

// Fetch the cart
$cart = isset($_SESSION['cart']) ? $_SESSION['cart'] : [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Your Cart</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gradient-to-b from-black via-gray-800 to-gray-900 text-white font-sans">

<?php include('navbar.php'); ?>

<section class="py-20 text-center">
    <h2 class="text-5xl font-extrabold text-white mb-10">Your Cart</h2>
</section>

<section class="py-10 px-4">
<?php if (empty($cart)) { ?>
    <p class="text-white text-center py-10">Your cart is empty. Add some products!</p>
<?php } else { ?>
<div class="overflow-x-auto bg-gray-800 rounded-lg shadow-xl">
    <table class="min-w-full table-auto text-white">
        <thead>
            <tr class="text-center">
                <th class="py-2 px-4">Product</th>
                <th class="py-2 px-4">Price</th>
                <th class="py-2 px-4">Quantity</th>
                <th class="py-2 px-4">Total</th>
                <th class="py-2 px-4">Remove</th>
            </tr>
        </thead>
        <tbody>
        <?php
        $total = 0;
        foreach ($cart as $product_id => $item) {
            if (!is_array($item)) continue;

            // Get current stock
            $product_sql = "SELECT quantity FROM products WHERE product_id = $product_id";
            $product_result = $conn->query($product_sql);
            $available_quantity = ($product_result && $product_result->num_rows > 0)
                ? $product_result->fetch_assoc()['quantity']
                : 1;

            $price = $item['price'];
            $quantity = $item['quantity'];
            $total_price = $price * $quantity;
            $total += $total_price;
        ?>
        <tr class="text-center">
        <td class="py-4 px-4">
  <div class="flex items-center space-x-4">
    <img src="<?php echo htmlspecialchars($item['image']); ?>" alt="<?php echo htmlspecialchars($item['product_name']); ?>" class="w-20 h-20 object-cover rounded shadow flex-shrink-0">
    <span class="text-white text-left font-medium"><?php echo htmlspecialchars($item['product_name']); ?></span>
  </div>
</td>

            <td class="py-2 px-4">$<?php echo number_format($price, 2); ?></td>
            <td class="py-2 px-4">
                <form action="update_cart.php" method="POST" class="flex items-center space-x-2 justify-center">
                    <input 
                        type="number" 
                        name="quantity" 
                        min="1" 
                        max="<?php echo $available_quantity; ?>" 
                        value="<?php echo $quantity; ?>" 
                        title="Max available: <?php echo $available_quantity; ?>" 
                        class="w-16 bg-gray-700 text-white py-1 px-2 rounded"
                    >
                    <input type="hidden" name="product_id" value="<?php echo $product_id; ?>">
                    <button type="submit" class="bg-gradient-to-r from-purple-500 to-indigo-500 hover:bg-gradient-to-l px-4 py-2 rounded-full text-sm font-semibold transition-all duration-300">Update</button>
                </form>
            </td>
            <td class="py-2 px-4">$<?php echo number_format($total_price, 2); ?></td>
            <td class="py-2 px-4">
                <form action="remove_from_cart.php" method="POST">
                    <input type="hidden" name="product_id" value="<?php echo $product_id; ?>">
                    <button type="submit" class="bg-red-500 hover:bg-red-600 px-4 py-2 rounded-full text-sm font-semibold transition-all duration-300">Remove</button>
                </form>
            </td>
        </tr>
        <?php } ?>
        </tbody>
    </table>
</div>

<!-- Total and Proceed to Checkout Button -->
<div class="mt-8 text-right pr-6">
    <p class="text-2xl font-bold text-white mb-4">Total: $<?php echo number_format($total, 2); ?></p>

    <a href="checkout.php" class="inline-block bg-green-500 hover:bg-green-600 text-white font-semibold px-6 py-3 rounded-full transition-all duration-300">
        Proceed to Checkout
    </a>
</div>

<?php } ?>
</section>

</body>
</html>
