<?php
session_start();
include('condb.php');

// Fetch total sales per day with status "delivered"
$sales_sql = "
    SELECT DATE(order_date) as order_day, SUM(total_price) as daily_sales
    FROM orders
    WHERE status = 'delivered'
    GROUP BY order_day
    ORDER BY order_day ASC
";
$sales_result = $conn->query($sales_sql);

$sales_data = [];
if ($sales_result->num_rows > 0) {
    while ($row = $sales_result->fetch_assoc()) {
        $sales_data[] = [
            'date' => $row['order_day'],
            'sales' => $row['daily_sales']
        ];
    }
} else {
    $sales_data = [];
}

$labels = [];
$data = [];
$total_sales = 0;
$highest_sales = 0;
$best_day = '';

foreach ($sales_data as $sale) {
    $labels[] = $sale['date'];
    $data[] = (float) $sale['sales'];
    $total_sales += $sale['sales'];

    if ($sale['sales'] > $highest_sales) {
        $highest_sales = $sale['sales'];
        $best_day = $sale['date'];
    }
}

$average_sales = count($data) > 0 ? round($total_sales / count($data), 2) : 0;

$labels_json = json_encode($labels);
$data_json = json_encode($data);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Dashboard</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script> <!-- Chart.js -->
</head>
<body class="bg-gray-900 text-white font-sans relative">

<!-- Include Admin Navbar -->
<?php include('admin_navbar.php'); ?>

<!-- Main Content Area -->
<div class="p-6 mt-24">
  <h1 class="text-3xl font-bold mb-6">Welcome to the Admin Dashboard</h1>

  <!-- Sales Chart Section -->
  <div class="bg-gray-800 p-6 rounded-lg shadow-lg mb-10">
    <h2 class="text-xl font-semibold mb-4">Sales Overview</h2>
    <canvas id="salesChart" width="400" height="200"></canvas>
  </div>

  <!-- Detailed Sales Analysis -->
  <div class="bg-gray-800 p-6 rounded-lg shadow-lg">
    <h2 class="text-2xl font-bold mb-6">📈 Sales Analysis</h2>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">

      <div class="bg-gray-700 p-6 rounded-lg">
        <h3 class="text-lg font-semibold mb-2 text-green-400">Total Sales</h3>
        <p class="text-2xl font-bold">$<?php echo number_format($total_sales, 2); ?></p>
      </div>

      <div class="bg-gray-700 p-6 rounded-lg">
        <h3 class="text-lg font-semibold mb-2 text-yellow-400">Average Daily Sales</h3>
        <p class="text-2xl font-bold">$<?php echo number_format($average_sales, 2); ?></p>
      </div>

      <div class="bg-gray-700 p-6 rounded-lg">
        <h3 class="text-lg font-semibold mb-2 text-purple-400">Best Selling Day</h3>
        <p class="text-2xl font-bold"><?php echo htmlspecialchars($best_day); ?></p>
      </div>

      <div class="bg-gray-700 p-6 rounded-lg">
        <h3 class="text-lg font-semibold mb-2 text-red-400">Highest Sales in a Day</h3>
        <p class="text-2xl font-bold">$<?php echo number_format($highest_sales, 2); ?></p>
      </div>

    </div>

    <div class="text-center mt-10">
      <p class="text-gray-400 italic">Track your sales growth and identify your best performing days for smarter decisions!</p>
    </div>

  </div>
</div>

<!-- Chart.js Script -->
<script>
  const ctx = document.getElementById('salesChart').getContext('2d');
  const salesChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: <?php echo $labels_json; ?>,
      datasets: [{
        label: 'Sales',
        data: <?php echo $data_json; ?>,
        backgroundColor: 'rgba(147, 51, 234, 0.7)',
        borderColor: 'rgba(147, 51, 234, 1)',
        borderWidth: 1,
        borderRadius: 8
      }]
    },
    options: {
      scales: {
        y: {
          beginAtZero: true,
          ticks: { color: 'white' }
        },
        x: {
          ticks: { color: 'white' }
        }
      },
      plugins: {
        legend: {
          labels: { color: 'white' }
        }
      }
    }
  });
</script>

</body>
</html>
