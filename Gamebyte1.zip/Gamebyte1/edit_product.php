<?php
session_start();
include('condb.php');

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: admin_login.php');
    exit();
}

// Fetch all products
$sql = "SELECT * FROM products";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Edit Products</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body class="bg-gray-800 text-white">
  
<?php include('admin_navbar.php'); ?>

<div class="container mx-auto p-8">
  <h1 class="text-3xl font-semibold mb-6">Manage Products (Edit)</h1>

  <!-- Search Bar -->
  <div class="relative mb-6">
    <input type="text" id="search-input" placeholder="Search for a product..." 
           class="w-full p-2 rounded bg-gray-600 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500">

    <!-- Search Dropdown -->
    <div id="search-results" class="absolute w-full bg-white text-black rounded shadow-lg mt-1 hidden z-50"></div>
  </div>

  <!-- Product List Table -->
  <table class="min-w-full bg-gray-700 rounded-lg shadow-lg">
    <thead>
      <tr>
        <th class="py-2 px-4 border-b text-left">Product Name</th>
        <th class="py-2 px-4 border-b text-left">Price</th>
        <th class="py-2 px-4 border-b text-left">Category</th>
        <th class="py-2 px-4 border-b text-left">Subcategory</th>
        <th class="py-2 px-4 border-b text-left">Image</th>
        <th class="py-2 px-4 border-b text-left">Action</th>
      </tr>
    </thead>
    <tbody>
      <?php
      if ($result->num_rows > 0) {
          while ($row = $result->fetch_assoc()) {
              echo "<tr>";
              echo "<td class='py-2 px-4'>" . htmlspecialchars($row['product_name']) . "</td>";
              echo "<td class='py-2 px-4'>$" . number_format($row['price'], 2) . "</td>";

              // Fetch category name
              $category_sql = "SELECT category_name FROM category WHERE category_id = " . $row['category_id'];
              $category_result = $conn->query($category_sql);
              $category_row = $category_result->fetch_assoc();
              $category_name = $category_row ? $category_row['category_name'] : 'N/A';
              echo "<td class='py-2 px-4'>" . htmlspecialchars($category_name) . "</td>";

              // Fetch subcategory name
              if (isset($row['subcategory_id'])) {
                  $subcategory_sql = "SELECT subcategory_name FROM subcategory WHERE subcategory_id = " . $row['subcategory_id'];
                  $subcategory_result = $conn->query($subcategory_sql);
                  $subcategory_row = $subcategory_result->fetch_assoc();
                  $subcategory_name = $subcategory_row ? $subcategory_row['subcategory_name'] : 'N/A';
              } else {
                  $subcategory_name = 'N/A';
              }
              echo "<td class='py-2 px-4'>" . htmlspecialchars($subcategory_name) . "</td>";

              echo "<td class='py-2 px-4'>
                      <img src='" . htmlspecialchars($row['image']) . "' alt='" . htmlspecialchars($row['product_name']) . "' class='w-20'>
                    </td>";
              echo "<td class='py-2 px-4'>
                      <a href='edit_single_product.php?product_id=" . $row['product_id'] . "' 
                         class='bg-yellow-500 text-white px-4 py-2 rounded hover:bg-yellow-600 transition'>
                         Edit
                      </a>
                    </td>";
              echo "</tr>";
          }
      } else {
          echo "<tr><td colspan='6' class='py-2 px-4 text-center'>No products found</td></tr>";
      }
      ?>
    </tbody>
  </table>
</div>

<!-- AJAX Search Script -->
<script>
const searchInput = document.getElementById('search-input');
const searchResults = document.getElementById('search-results');

searchInput.addEventListener('input', function() {
  const query = this.value.trim();

  if (query.length === 0) {
    searchResults.classList.add('hidden');
    searchResults.innerHTML = '';
    return;
  }

  fetch(`search_product_admin.php?query=${encodeURIComponent(query)}`)
  .then(response => response.json())
  .then(data => {
    if (data.length === 0) {
      searchResults.classList.add('hidden');
      searchResults.innerHTML = '';
      return;
    }

    searchResults.innerHTML = '';
    data.forEach(product => {
      const item = document.createElement('div');
      item.className = 'flex items-center p-2 hover:bg-gray-200 cursor-pointer';
      item.innerHTML = `
        <img src="${product.image}" alt="${product.product_name}" class="w-12 h-12 object-cover rounded mr-4">
        <div class="flex-1">
          <p class="font-semibold">${product.product_name}</p>
        </div>
      `;
      item.addEventListener('click', () => {
        window.location.href = `edit_single_product.php?product_id=${product.product_id}`;
      });
      searchResults.appendChild(item);
    });

    searchResults.classList.remove('hidden');
  })
  .catch(error => {
    console.error('Error:', error);
  });
});
</script>

</body>
</html>

