<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
$currentPage = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Navbar</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body>

<!-- Navbar -->
<nav class="flex items-center justify-between px-6 py-4 bg-gradient-to-r from-purple-600 to-indigo-700 shadow-lg relative">
  <!-- Menu Icon on the Left -->
  <button id="toggleSidebar" class="text-white focus:outline-none absolute left-6 z-50">
    <img src="https://img.icons8.com/ios-filled/30/ffffff/menu--v1.png" alt="Menu" id="menuIcon"/>
  </button>

  <!-- Dashboard Title Centered -->
  <div class="w-full text-center">
    <span class="text-2xl font-bold">Admin Dashboard</span>
  </div>
</nav>

<!-- Overlay -->
<div id="overlay" class="fixed inset-0 bg-black bg-opacity-50 hidden z-40"></div>

<!-- Sidebar -->
<div id="sidebar" class="fixed top-0 left-0 h-full w-64 bg-gray-800 shadow-xl transform -translate-x-full transition-transform duration-300 z-50 pt-20 overflow-y-auto">
  <div class="p-6 space-y-4">
    <h2 class="text-xl font-bold mb-6">Dashboard Menu</h2>

    <a href="admin_dashboard.php" class="flex items-center px-4 py-2 rounded <?php echo $currentPage == 'admin_dashboard.php' ? 'bg-purple-700' : 'hover:bg-purple-700'; ?>">
      <img src="https://img.icons8.com/ios-filled/24/ffffff/home.png" class="mr-3" alt="Home"/> Home
    </a>

    <a href="add_product.php" class="flex items-center px-4 py-2 rounded <?php echo $currentPage == 'add_product.php' ? 'bg-purple-700' : 'hover:bg-purple-700'; ?>">
      <img src="https://img.icons8.com/ios-filled/24/ffffff/plus-math.png" class="mr-3" alt="Add Product"/> Add Product
    </a>

    <a href="delete_product.php" class="flex items-center px-4 py-2 rounded <?php echo $currentPage == 'delete_product.php' ? 'bg-purple-700' : 'hover:bg-purple-700'; ?>">
      <img src="https://img.icons8.com/ios-filled/24/ffffff/delete-sign.png" class="mr-3" alt="Delete Product"/> Delete Product
    </a>

    <a href="edit_product.php" class="flex items-center px-4 py-2 rounded <?php echo $currentPage == 'edit_product.php' ? 'bg-purple-700' : 'hover:bg-purple-700'; ?>">
      <img src="https://img.icons8.com/ios-filled/24/ffffff/edit--v1.png" class="mr-3" alt="Edit Product"/> Edit Product
    </a>

    <a href="add_category.php" class="flex items-center px-4 py-2 rounded <?php echo $currentPage == 'add_category.php' ? 'bg-purple-700' : 'hover:bg-purple-700'; ?>">
      <img src="https://img.icons8.com/ios-filled/24/ffffff/add-list.png" class="mr-3" alt="Add Category"/> Add Category
    </a>

    <a href="delete_category.php" class="flex items-center px-4 py-2 rounded <?php echo $currentPage == 'delete_category.php' ? 'bg-purple-700' : 'hover:bg-purple-700'; ?>">
      <img src="https://img.icons8.com/ios-filled/24/ffffff/delete-forever.png" class="mr-3" alt="Delete Category"/> Delete Category
    </a>

    <a href="edit_category.php" class="flex items-center px-4 py-2 rounded <?php echo $currentPage == 'edit_category.php' ? 'bg-purple-700' : 'hover:bg-purple-700'; ?>">
      <img src="https://img.icons8.com/ios-filled/24/ffffff/edit-property.png" class="mr-3" alt="Edit Category"/> Edit Category
    </a>

    <a href="add_subcategory.php" class="flex items-center px-4 py-2 rounded <?php echo $currentPage == 'add_subcategory.php' ? 'bg-purple-700' : 'hover:bg-purple-700'; ?>">
      <img src="https://img.icons8.com/ios-filled/24/ffffff/add-property.png" class="mr-3" alt="Add Subcategory"/> Add Subcategory
    </a>

    <a href="edit_subcategory.php" class="flex items-center px-4 py-2 rounded <?php echo $currentPage == 'edit_subcategory.php' ? 'bg-purple-700' : 'hover:bg-purple-700'; ?>">
      <img src="https://img.icons8.com/ios-filled/24/ffffff/edit-row.png" class="mr-3" alt="Edit Subcategory"/> Edit Subcategory
    </a>

    <a href="delete_subcategory.php" class="flex items-center px-4 py-2 rounded <?php echo $currentPage == 'delete_subcategory.php' ? 'bg-purple-700' : 'hover:bg-purple-700'; ?>">
      <img src="https://img.icons8.com/ios-filled/24/ffffff/delete-row.png" class="mr-3" alt="Delete Subcategory"/> Delete Subcategory
    </a>

    <a href="view_customers_orders.php" class="flex items-center px-4 py-2 rounded <?php echo $currentPage == 'view_customers_orders.php' ? 'bg-purple-700' : 'hover:bg-purple-700'; ?>">
      <img src="https://img.icons8.com/ios-filled/24/ffffff/purchase-order.png" class="mr-3" alt="View Orders"/> View Customer Orders
    </a>

    <a href="graph_status.php" class="flex items-center px-4 py-2 rounded <?php echo $currentPage == 'graph_status.php' ? 'bg-purple-700' : 'hover:bg-purple-700'; ?>">
      <img src="https://img.icons8.com/ios-filled/24/ffffff/combo-chart.png" class="mr-3" alt="Graph Status"/> Graph Status
    </a>
   

    <a href="logout.php" class="flex items-center text-red-500 hover:bg-red-800 px-4 py-2 rounded">
      <img src="https://img.icons8.com/ios-filled/24/ff0000/logout-rounded.png" class="mr-3" alt="Logout"/> Logout
    </a>

  </div>
</div>

<!-- Sidebar Toggle Script -->
<script>
  const sidebar = document.getElementById('sidebar');
  const overlay = document.getElementById('overlay');
  const toggleBtn = document.getElementById('toggleSidebar');

  toggleBtn.addEventListener('click', () => {
    sidebar.classList.toggle('-translate-x-full');
    overlay.classList.toggle('hidden');
  });

  overlay.addEventListener('click', () => {
    sidebar.classList.add('-translate-x-full');
    overlay.classList.add('hidden');
  });
</script>

</body>
</html>
