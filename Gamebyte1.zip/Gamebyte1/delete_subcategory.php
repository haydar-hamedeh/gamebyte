<?php
include('condb.php');
session_start();

// Handle delete request
if (isset($_POST['subcategory_id'])) {
    $subcategory_id = intval($_POST['subcategory_id']);
    $delete_sql = "DELETE FROM subcategory WHERE subcategory_id = $subcategory_id";

    if ($conn->query($delete_sql)) {
        $_SESSION['message'] = "Subcategory deleted successfully!";
    } else {
        $_SESSION['error'] = "Error deleting subcategory: " . $conn->error;
    }
    header('Location: delete_subcategory.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Delete Subcategory</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body class="bg-gray-900 text-white font-sans min-h-screen">
  <?php include('admin_navbar.php'); ?>

  <div class="max-w-lg mx-auto p-10">
    <h2 class="text-3xl font-bold mb-8 text-center">Delete Subcategory</h2>

    <!-- Delete Subcategory Form -->
    <form action="delete_subcategory.php" method="POST" class="bg-gray-800 p-6 rounded-lg shadow-lg">
      <div class="mb-6">
        <label class="block mb-2 text-sm font-bold" for="subcategory_id">Select Subcategory to Delete:</label>
        <select id="subcategory_id" name="subcategory_id" required class="w-full px-4 py-2 text-black rounded-md focus:ring-2 focus:ring-red-500">
          <option value="">Select a subcategory</option>
          <?php
          $subs = $conn->query("SELECT subcategory_id, subcategory_name FROM subcategory");
          if ($subs->num_rows > 0) {
              while ($row = $subs->fetch_assoc()) {
                  echo "<option value='" . $row['subcategory_id'] . "'>" . htmlspecialchars($row['subcategory_name']) . "</option>";
              }
          } else {
              echo "<option disabled>No subcategories available</option>";
          }
          ?>
        </select>
      </div>

      <button type="submit" class="w-full bg-red-600 hover:bg-red-700 py-3 rounded-full text-white font-semibold">
        Delete Subcategory
      </button>
    </form>
  </div>

  <!-- SweetAlert2 for success or error -->
  <?php if (isset($_SESSION['message'])): ?>
  <script>
  Swal.fire({
      icon: 'success',
      title: 'Deleted!',
      text: '<?php echo $_SESSION['message']; ?>',
      confirmButtonColor: '#22C55E'
  });
  </script>
  <?php unset($_SESSION['message']); endif; ?>

  <?php if (isset($_SESSION['error'])): ?>
  <script>
  Swal.fire({
      icon: 'error',
      title: 'Error!',
      text: '<?php echo $_SESSION['error']; ?>',
      confirmButtonColor: '#EF4444'
  });
  </script>
  <?php unset($_SESSION['error']); endif; ?>

</body>
</html>
