<?php
session_start();
include('condb.php');

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Query the database to get the hashed password
    $sql = "SELECT * FROM admin WHERE email = '$email'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        // Verify the password using password_verify
        if (password_verify($password, $row['password'])) {
            $_SESSION['admin_id'] = $row['admin_id']; // Save the admin's ID in session
            header("Location: admin_dashboard.php"); // Redirect to admin dashboard
            exit();
        } else {
            $_SESSION['error'] = "Invalid username or password.";
        }
    } else {
        $_SESSION['error'] = "Admin not found.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Login</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.0.3/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-900 text-white font-sans">

<!-- Login Form -->
<div class="max-w-sm mx-auto mt-20 bg-gray-800 p-6 rounded-lg shadow-lg">
    <h2 class="text-2xl font-bold text-center mb-6">Admin Login</h2>

    <!-- Display error message -->
    <?php if (isset($_SESSION['error'])) { ?>
        <div class="bg-red-600 text-white p-4 rounded mb-6"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
    <?php } ?>

    <form action="admin_login.php" method="POST">
        <div class="mb-4">
            <label for="email" class="block text-lg">Email:</label>
            <input type="email" name="email" id="email" required 
                class="w-full p-3 rounded-md bg-gray-700 text-white border border-gray-600 focus:outline-none focus:border-purple-500" 
                placeholder="Enter email"
                value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
        </div>
        
        <div class="mb-4">
            <label for="password" class="block text-lg">Password:</label>
            <input type="password" name="password" id="password" required 
                class="w-full p-3 rounded-md bg-gray-700 text-white border border-gray-600 focus:outline-none focus:border-purple-500" 
                placeholder="Enter password"
                value="">
        </div>
        
        <button type="submit" class="w-full bg-gradient-to-r from-purple-500 to-indigo-500 hover:bg-gradient-to-l px-6 py-3 rounded-full text-sm font-semibold transition-all duration-300">Login</button>
    </form>

    <p class="mt-4 text-center">
        Don't have an account? <a href="admin_signup.php" class="text-purple-400 hover:text-purple-600">Sign Up</a>
    </p>
</div>

</body>
</html>

