<?php
header('Content-Type: application/json');

// DB connection settings
$host = 'localhost';
$user = 'root';
$password = ''; // change if you set a password
$dbname = 'gamebytedb';

// Create DB connection
$conn = new mysqli($host, $user, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    echo json_encode(['reply' => 'Database connection failed.']);
    exit;
}

// Get user input
$data = json_decode(file_get_contents('php://input'), true);
$input = strtolower(trim($data['message']));

// Search for a matching question using LIKE for flexible matching
$stmt = $conn->prepare("SELECT answer FROM chatbot_responses WHERE LOWER(question) LIKE CONCAT('%', ?, '%') LIMIT 1");
$stmt->bind_param("s", $input);
$stmt->execute();
$result = $stmt->get_result();

// Default reply
$reply = "Sorry, I didn't understand that. You can ask about products, orders, or say hi. Try using keywords like cart, order, product, about, or hello!";

// If a match is found, use the answer
if ($row = $result->fetch_assoc()) {
    $reply = $row['answer'];
} else {
    // Try a second chance: search by splitting into keywords
    $words = explode(' ', $input);
    foreach ($words as $word) {
        $word = trim($word);
        if (strlen($word) > 2) { // ignore very small words
            $stmt = $conn->prepare("SELECT answer FROM chatbot_responses WHERE LOWER(question) LIKE CONCAT('%', ?, '%') LIMIT 1");
            $stmt->bind_param("s", $word);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($row = $result->fetch_assoc()) {
                $reply = $row['answer'];
                break;
            }
        }
    }
}

$stmt->close();
$conn->close();

// Return the reply
echo json_encode(['reply' => $reply]);
?>
