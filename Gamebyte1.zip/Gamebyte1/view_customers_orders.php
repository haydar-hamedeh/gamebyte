<?php
include('condb.php');
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: admin_login.php');
    exit();
}

// Handle Status Update Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $order_id = intval($_POST['order_id']);
    $new_status = $_POST['status'];

    $allowed_statuses = ['pending', 'delivering', 'delivered', 'cancelled'];
    if (in_array($new_status, $allowed_statuses)) {

        // If admin cancels the order, restore product quantities
        if ($new_status == 'cancelled') {
            $items_sql = "SELECT product_id, quantity FROM order_items WHERE order_id = ?";
            $stmt_items = $conn->prepare($items_sql);
            $stmt_items->bind_param('i', $order_id);
            $stmt_items->execute();
            $items_result = $stmt_items->get_result();

            while ($item = $items_result->fetch_assoc()) {
                $product_id = $item['product_id'];
                $ordered_quantity = $item['quantity'];

                // Update product stock
                $update_product_sql = "UPDATE products SET quantity = quantity + ? WHERE product_id = ?";
                $stmt_update = $conn->prepare($update_product_sql);
                $stmt_update->bind_param('ii', $ordered_quantity, $product_id);
                $stmt_update->execute();
            }
        }

        // Now update the order status
        $update_sql = "UPDATE orders SET status = ? WHERE order_id = ?";
        $stmt = $conn->prepare($update_sql);
        $stmt->bind_param('si', $new_status, $order_id);
        $stmt->execute();
    }
}

// Fetch all orders with customer info
$sql = "
SELECT 
    o.order_id, o.total_price, o.shipping_address, o.phone_number, o.payment_method, o.order_date, o.status,
    c.customer_username, c.email
FROM orders o
JOIN customer c ON o.customer_id = c.customer_id
ORDER BY o.order_date DESC
";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Customer Orders</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-900 text-white font-sans">

    <!-- Navbar -->
    <?php include('admin_navbar.php'); ?>

    <h1 class="text-4xl font-bold mb-8 text-center">Customer Orders</h1>

    <?php if ($result->num_rows > 0) { ?>
        <div class="overflow-x-auto">
            <table class="w-full table-auto border-collapse">
                <thead>
                    <tr class="bg-gray-700">
                        <th class="p-4 border">Order ID</th>
                        <th class="p-4 border">Customer Name</th>
                        <th class="p-4 border">Email</th>
                        <th class="p-4 border">Phone</th>
                        <th class="p-4 border">Shipping Address</th>
                        <th class="p-4 border">Payment Method</th>
                        <th class="p-4 border">Total Price</th>
                        <th class="p-4 border">Order Date</th>
                        <th class="p-4 border">Products</th>
                        <th class="p-4 border">Order Status</th>
                        <th class="p-4 border">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($order = $result->fetch_assoc()) { ?>
                        <tr class="bg-gray-800 hover:bg-gray-700">
                            <td class="p-4 border"><?php echo $order['order_id']; ?></td>
                            <td class="p-4 border"><?php echo htmlspecialchars($order['customer_username']); ?></td>
                            <td class="p-4 border"><?php echo htmlspecialchars($order['email']); ?></td>
                            <td class="p-4 border"><?php echo htmlspecialchars($order['phone_number']); ?></td>
                            <td class="p-4 border"><?php echo htmlspecialchars($order['shipping_address']); ?></td>
                            <td class="p-4 border"><?php echo htmlspecialchars($order['payment_method']); ?></td>
                            <td class="p-4 border">$<?php echo number_format($order['total_price'], 2); ?></td>
                            <td class="p-4 border"><?php echo $order['order_date']; ?></td>
                            <td class="p-4 border">
                                <?php
                                    $order_id = $order['order_id'];
                                    $products_sql = "
                                        SELECT p.product_name, oi.quantity
                                        FROM order_items oi
                                        JOIN products p ON oi.product_id = p.product_id
                                        WHERE oi.order_id = $order_id
                                    ";
                                    $products_result = $conn->query($products_sql);
                                    if ($products_result->num_rows > 0) {
                                        while($product = $products_result->fetch_assoc()) {
                                            echo "<div>- " . htmlspecialchars($product['product_name']) . " (x" . $product['quantity'] . ")</div>";
                                        }
                                    } else {
                                        echo "No products.";
                                    }
                                ?>
                            </td>

                           <!-- Order Status with Color + Dropdown -->
                           <td class="p-4 border">
                               <form action="view_customers_orders.php" method="POST">
                                   <input type="hidden" name="order_id" value="<?php echo $order['order_id']; ?>">
                                   <select name="status" class="bg-gray-700 text-white rounded p-2 
                                       <?php 
                                           // Assign color based on status
                                           echo ($order['status'] == 'pending') ? 'text-yellow-400' : '';
                                           echo ($order['status'] == 'delivering') ? 'text-blue-400' : '';
                                           echo ($order['status'] == 'delivered') ? 'text-green-400' : '';
                                           echo ($order['status'] == 'cancelled') ? 'text-red-400' : '';
                                       ?>">
                                       <option value="pending" <?php if($order['status'] == 'pending') echo 'selected'; ?>>Pending</option>
                                       <option value="delivering" <?php if($order['status'] == 'delivering') echo 'selected'; ?>>Delivering</option>
                                       <option value="delivered" <?php if($order['status'] == 'delivered') echo 'selected'; ?>>Delivered</option>
                                       <option value="cancelled" <?php if($order['status'] == 'cancelled') echo 'selected'; ?>>Cancelled</option>
                                   </select>
                           </td>

                            <!-- Update Button -->
                            <td class="p-4 border">
                                <button type="submit" name="update_status" class="bg-blue-500 hover:bg-blue-600 px-4 py-2 rounded-full text-white text-sm">
                                    Update
                                </button>
                            </form>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    <?php } else { ?>
        <p class="text-center text-xl">No orders found.</p>
    <?php } ?>

</body>
</html>
