<?php
include('condb.php');
session_start();

// Check if subcategory_id is set
if (!isset($_GET['subcategory_id'])) {
    header('Location: store.php');
    exit();
}

$subcategory_id = intval($_GET['subcategory_id']);

// Fetch subcategory info
$subcategory_sql = "SELECT * FROM subcategory WHERE subcategory_id = ?";
$stmt_sub = $conn->prepare($subcategory_sql);
$stmt_sub->bind_param('i', $subcategory_id);
$stmt_sub->execute();
$sub_result = $stmt_sub->get_result();

if ($sub_result->num_rows === 0) {
    header('Location: store.php');
    exit();
}

$subcategory = $sub_result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo htmlspecialchars($subcategory['subcategory_name']); ?> - Gamebyte Store</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-b from-black via-gray-800 to-gray-900 text-white font-sans">

<?php include('navbar.php'); ?>

<section class="py-20 px-4">
    <h2 class="text-5xl font-extrabold mb-10 text-center bg-clip-text text-transparent bg-gradient-to-r from-purple-600 to-indigo-500">
        <?php echo htmlspecialchars($subcategory['subcategory_name']); ?>
    </h2>

    <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8 p-4">
        <?php
        // Fetch products that belong to this subcategory
        $products_sql = "SELECT * FROM products WHERE subcategory_id = ?";
        $stmt_prod = $conn->prepare($products_sql);
        $stmt_prod->bind_param('i', $subcategory_id);
        $stmt_prod->execute();
        $products_result = $stmt_prod->get_result();

        if ($products_result->num_rows > 0) {
            while ($product = $products_result->fetch_assoc()) {
                echo "<div class='bg-gray-800 p-6 rounded-lg text-center shadow-lg transition-transform transform hover:scale-105'>";
                echo "<img src='" . $product['image'] . "' alt='" . htmlspecialchars($product['product_name']) . "' class='w-full h-48 object-cover mb-4 rounded-lg'>";
                echo "<h3 class='text-2xl font-bold text-white mb-2'>" . htmlspecialchars($product['product_name']) . "</h3>";
                echo "<p class='text-sm text-gray-400 mb-2'>" . htmlspecialchars($product['description']) . "</p>";
                echo "<p class='text-lg text-gray-500 mb-4'>Quantity: " . htmlspecialchars($product['quantity']) . "</p>";

                echo "<div class='flex flex-col gap-2'>";
                echo "<a href='product.php?id=" . $product['product_id'] . "' class='bg-gradient-to-r from-green-500 to-teal-500 text-white hover:bg-gradient-to-l px-4 py-2 rounded-full text-sm font-semibold transition-all duration-300'>View Details</a>";
                echo "</div>";
                echo "</div>";
            }
        } else {
            echo "<p class='text-center text-white text-lg'>No products found in this subcategory.</p>";
        }
        ?>
    </div>
</section>

<!-- Floating Chatbot Button -->
<div id="chatbot-toggle" style="position: fixed; bottom: 30px; right: 30px; background-color: #3b78e6; color: white; border: none; border-radius: 50%; width: 60px; height: 60px; font-size: 24px; display: flex; justify-content: center; align-items: center; cursor: pointer; z-index: 9999;">
  💬
</div>

<!-- Chatbot Window -->
<div id="chatbot-window" class="hidden chatbot-window-style">
  <div class="chatbot-header">GameByte Chatbot</div>
  <div id="chat-content" class="chatbot-content"></div>
  <div class="chatbot-input-area">
    <input type="text" id="user-message" placeholder="Type a message..." class="chatbot-input">
  </div>
</div>

<!-- Chatbot Script -->
<script>
const toggleBtn = document.getElementById('chatbot-toggle');
const chatWindow = document.getElementById('chatbot-window');
const userInput = document.getElementById('user-message');
const chatContent = document.getElementById('chat-content');

toggleBtn.addEventListener('click', () => {
  if (chatWindow.classList.contains('hidden')) {
    chatWindow.classList.remove('hidden');
    setTimeout(() => {
      chatWindow.style.transform = 'scale(1)';
      chatWindow.style.opacity = '1';
    }, 10);
  } else {
    chatWindow.style.transform = 'scale(0)';
    chatWindow.style.opacity = '0';
    setTimeout(() => {
      chatWindow.classList.add('hidden');
    }, 300);
  }
});

userInput.addEventListener('keypress', function(e) {
  if (e.key === 'Enter' && userInput.value.trim() !== '') {
    const userMsg = userInput.value.trim();
    displayMessage(userMsg, 'user');
    userInput.value = '';

    fetch('/GameByte1/chatbot.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: userMsg })
    })
    .then(response => response.json())
    .then(data => {
      const botReply = data.reply;
      displayMessage(botReply, 'bot');
    })
    .catch(error => {
      console.error('Error:', error);
      displayMessage('Sorry, something went wrong.', 'bot');
    });
  }
});

function displayMessage(message, sender) {
  const messageDiv = document.createElement('div');
  messageDiv.classList.add('message');
  messageDiv.classList.add(sender === 'user' ? 'user-message' : 'bot-message');
  messageDiv.innerText = message;
  chatContent.appendChild(messageDiv);
  chatContent.scrollTop = chatContent.scrollHeight;
}
</script>

<!-- Chatbot Styles -->
<style>
/* Full Chatbot Window */
.chatbot-window-style {
  position: fixed;
  bottom: 100px;
  right: 30px;
  width: 320px;
  height: 400px;
  background: #fff;
  border-radius: 15px;
  box-shadow: 0 4px 15px rgba(0,0,0,0.3);
  z-index: 9999;
  flex-direction: column;
  overflow: hidden;
  transform: scale(0);
  opacity: 0;
  transition: all 0.3s ease;
  display: flex;
}

/* Chatbot header */
.chatbot-header {
  background-color: #3b78e6;
  color: white;
  padding: 12px;
  font-weight: bold;
  text-align: center;
  font-size: 18px;
  border-top-left-radius: 15px;
  border-top-right-radius: 15px;
}

/* Messages area */
.chatbot-content {
  flex: 1;
  padding: 10px;
  overflow-y: auto;
  font-size: 14px;
  display: flex;
  flex-direction: column;
  gap: 10px;
  background: #f9f9f9;
}

/* Input area */
.chatbot-input-area {
  padding: 10px;
  border-top: 1px solid #ddd;
  background: #f1f0f0;
}

/* Input field */
.chatbot-input {
  width: 100%;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 10px;
  font-size: 14px;
  outline: none;
  background: white;
  color: black;
}
.chatbot-input:focus {
  border-color: #3b78e6;
}

/* Message Styles */
.message {
  max-width: 70%;
  padding: 8px 12px;
  border-radius: 20px;
  animation: fadeIn 0.5s;
}
.user-message {
  background-color: #3b78e6;
  color: white;
  align-self: flex-end;
  text-align: right;
}
.bot-message {
  background-color: #e5e5ea;
  color: black;
  align-self: flex-start;
  text-align: left;
}

@keyframes fadeIn {
  from { opacity: 0; transform: translateY(10px); }
  to { opacity: 1; transform: translateY(0); }
}
</style>
<footer class="bg-gray-800 text-center py-10 text-gray-400 text-sm mt-20">
    &copy; <?php echo date('Y'); ?> Gamebyte Store. All rights reserved.
</footer>

</body>
</html>
