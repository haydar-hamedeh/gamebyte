<?php
include('condb.php');
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Gamebyte Store</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    tailwind.config = {
      theme: {
        extend: {
          animation: {
            fadeIn: 'fadeIn 2s ease-out',
            pulseFast: 'pulse 1.5s infinite',
            bounceIn: 'bounceIn 1s ease-out',
          },
          keyframes: {
            fadeIn: { '0%': { opacity: 0 }, '100%': { opacity: 1 } },
            bounceIn: { '0%': { transform: 'scale(0.5)', opacity: 0 }, '100%': { transform: 'scale(1)', opacity: 1 } }
          }
        }
      }
    }
  </script>
</head>

<body class="bg-gradient-to-b from-black via-gray-800 to-gray-900 text-white font-sans relative">

<?php include('navbar.php'); ?>

<!-- ✅ Welcome Banner -->
<?php if (isset($_SESSION['customer_username'])): ?>
  <div class="text-center py-6 px-4 bg-gradient-to-r from-indigo-700 to-purple-700 shadow-lg animate-bounceIn">
    <h1 class="text-3xl md:text-4xl font-extrabold text-white tracking-wide">
      👋 Welcome back, <span class="text-yellow-300"><?php echo htmlspecialchars($_SESSION['customer_username']); ?></span>!
    </h1>
    <p class="text-gray-200 mt-2 text-lg">Let’s power up your gaming experience today 🎮</p>
  </div>
<?php endif; ?>

<!-- Featured Categories Section -->
<section class="py-20 px-6 bg-gradient-to-r from-purple-800 to-indigo-900 text-white">
  <h2 class="text-4xl font-extrabold mb-12 text-center animate-bounceIn">Featured Categories</h2>
  <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8 text-center">
    <div class="bg-gray-700 p-6 rounded-lg shadow-lg hover:scale-105 transition-transform duration-300">
      <img src="https://img.icons8.com/fluency/96/ps-controller.png" class="mx-auto mb-4" alt="PS5">
      <h3 class="text-2xl font-bold mb-2">PlayStation</h3>
      <p class="text-gray-300">Explore PS5 consoles, games and accessories.</p>
    </div>
    <div class="bg-gray-700 p-6 rounded-lg shadow-lg hover:scale-105 transition-transform duration-300">
      <img src="https://img.icons8.com/color/96/xbox-x.png" class="mx-auto mb-4" alt="Xbox">
      <h3 class="text-2xl font-bold mb-2">Xbox</h3>
      <p class="text-gray-300">Get the best Xbox gaming gear and exclusives.</p>
    </div>
    <div class="bg-gray-700 p-6 rounded-lg shadow-lg hover:scale-105 transition-transform duration-300">
    <img src="https://img.icons8.com/fluency/96/laptop.png" class="mx-auto mb-4" alt="PC Gaming">
      <h3 class="text-2xl font-bold mb-2">PC Gaming</h3>
      <p class="text-gray-300">Shop PCs, gaming chairs, monitors & more.</p>
    </div>
  </div>
</section>

<!-- Products Section -->
<section id="products" class="py-20 px-4 animate-fadeIn">
  <h2 class="text-5xl font-extrabold mb-10 text-center text-gradient bg-clip-text text-transparent bg-gradient-to-r from-purple-600 to-indigo-500">
    Our Products
  </h2>

  <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8 p-4">
    <?php
    $sql = "SELECT * FROM products LIMIT 6";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
      while ($row = $result->fetch_assoc()) {
        echo "<div class='bg-gray-800 p-6 rounded-lg text-center shadow-lg transition-transform transform hover:scale-105'>";
        echo "<img src='" . $row['image'] . "' alt='" . htmlspecialchars($row['product_name']) . "' class='w-full h-48 object-cover mb-4 rounded-lg'>";
        echo "<h3 class='text-2xl font-bold text-white mb-2'>" . htmlspecialchars($row['product_name']) . "</h3>";
        echo "<p class='text-sm text-gray-400 mb-2'>" . htmlspecialchars($row['description']) . "</p>";
        echo "<p class='text-lg text-gray-500 mb-4'>Quantity: " . htmlspecialchars($row['quantity']) . "</p>";
        echo "<div class='flex flex-col gap-2'>";
        echo "<a href='store.php' class='bg-gradient-to-r from-purple-500 to-indigo-500 text-white hover:bg-gradient-to-l px-4 py-2 rounded-full text-sm font-semibold transition-all duration-300'>See More</a>";
        echo "<a href='product.php?id=" . $row['product_id'] . "' class='bg-gradient-to-r from-green-500 to-teal-500 text-white hover:bg-gradient-to-l px-4 py-2 rounded-full text-sm font-semibold transition-all duration-300'>View Details</a>";
        echo "</div></div>";
      }
    } else {
      echo "<p class='text-center text-white text-lg'>No products available.</p>";
    }
    ?>
  </div>
</section>

<!-- New Arrivals Section -->
<section class="py-20 px-4 bg-gradient-to-b from-gray-900 to-black text-white animate-fadeIn">
  <h2 class="text-5xl font-extrabold mb-10 text-center text-gradient bg-clip-text text-transparent bg-gradient-to-r from-green-400 to-blue-500">
    New Arrivals
  </h2>
  <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8 p-4">
    <?php
    $new_sql = "SELECT * FROM products ORDER BY product_id DESC LIMIT 4";
    $new_result = $conn->query($new_sql);

    if ($new_result->num_rows > 0) {
      while ($new = $new_result->fetch_assoc()) {
        echo "<div class='bg-gray-800 p-6 rounded-lg text-center shadow-lg transition-transform transform hover:scale-105'>";
        echo "<img src='" . htmlspecialchars($new['image']) . "' alt='" . htmlspecialchars($new['product_name']) . "' class='w-full h-48 object-cover mb-4 rounded-lg'>";
        echo "<h3 class='text-2xl font-bold text-white mb-2'>" . htmlspecialchars($new['product_name']) . "</h3>";
        echo "<p class='text-sm text-gray-400 mb-2'>$" . number_format($new['price'], 2) . "</p>";
        echo "<a href='product.php?id=" . $new['product_id'] . "' class='bg-gradient-to-r from-green-500 to-teal-500 text-white hover:bg-gradient-to-l px-4 py-2 rounded-full text-sm font-semibold transition-all duration-300'>View Details</a>";
        echo "</div>";
      }
    } else {
      echo "<p class='text-center text-white text-lg'>No new products available.</p>";
    }
    ?>
  </div>
</section>

<!-- Floating Chatbot Button -->
<div id="chatbot-toggle" style="position: fixed; bottom: 30px; right: 30px; background-color: #3b78e6; color: white; border: none; border-radius: 50%; width: 60px; height: 60px; font-size: 24px; display: flex; justify-content: center; align-items: center; cursor: pointer; z-index: 9999;">
  💬
</div>

<!-- Chatbot Window -->
<div id="chatbot-window" class="hidden chatbot-window-style">
  <div class="chatbot-header">GameByte Chatbot</div>
  <div id="chat-content" class="chatbot-content"></div>
  <div class="chatbot-input-area">
    <input type="text" id="user-message" placeholder="Type a message..." class="chatbot-input">
  </div>
</div>

<!-- Chatbot Script -->
<script>
const toggleBtn = document.getElementById('chatbot-toggle');
const chatWindow = document.getElementById('chatbot-window');
const userInput = document.getElementById('user-message');
const chatContent = document.getElementById('chat-content');

toggleBtn.addEventListener('click', () => {
  if (chatWindow.classList.contains('hidden')) {
    chatWindow.classList.remove('hidden');
    setTimeout(() => {
      chatWindow.style.transform = 'scale(1)';
      chatWindow.style.opacity = '1';
    }, 10);
  } else {
    chatWindow.style.transform = 'scale(0)';
    chatWindow.style.opacity = '0';
    setTimeout(() => {
      chatWindow.classList.add('hidden');
    }, 300);
  }
});

userInput.addEventListener('keypress', function(e) {
  if (e.key === 'Enter' && userInput.value.trim() !== '') {
    const userMsg = userInput.value.trim();
    displayMessage(userMsg, 'user');
    userInput.value = '';

    fetch('/GameByte1/chatbot.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: userMsg })
    })
    .then(response => response.json())
    .then(data => {
      const botReply = data.reply;
      displayMessage(botReply, 'bot');
    })
    .catch(error => {
      console.error('Error:', error);
      displayMessage('Sorry, something went wrong.', 'bot');
    });
  }
});

function displayMessage(message, sender) {
  const messageDiv = document.createElement('div');
  messageDiv.classList.add('message');
  messageDiv.classList.add(sender === 'user' ? 'user-message' : 'bot-message');
  messageDiv.innerText = message;
  chatContent.appendChild(messageDiv);
  chatContent.scrollTop = chatContent.scrollHeight;
}
</script>

<!-- Chatbot Styles -->
<style>
/* Full Chatbot Window */
.chatbot-window-style {
  position: fixed;
  bottom: 100px;
  right: 30px;
  width: 320px;
  height: 400px;
  background: #fff;
  border-radius: 15px;
  box-shadow: 0 4px 15px rgba(0,0,0,0.3);
  z-index: 9999;
  flex-direction: column;
  overflow: hidden;
  transform: scale(0);
  opacity: 0;
  transition: all 0.3s ease;
  display: flex;
}

/* Chatbot header */
.chatbot-header {
  background-color: #3b78e6;
  color: white;
  padding: 12px;
  font-weight: bold;
  text-align: center;
  font-size: 18px;
  border-top-left-radius: 15px;
  border-top-right-radius: 15px;
}

/* Messages area */
.chatbot-content {
  flex: 1;
  padding: 10px;
  overflow-y: auto;
  font-size: 14px;
  display: flex;
  flex-direction: column;
  gap: 10px;
  background: #f9f9f9;
}

/* Input area */
.chatbot-input-area {
  padding: 10px;
  border-top: 1px solid #ddd;
  background: #f1f0f0;
}

/* Input field */
.chatbot-input {
  width: 100%;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 10px;
  font-size: 14px;
  outline: none;
  background: white;
  color: black;
}
.chatbot-input:focus {
  border-color: #3b78e6;
}

/* Message Styles */
.message {
  max-width: 70%;
  padding: 8px 12px;
  border-radius: 20px;
  animation: fadeIn 0.5s;
}
.user-message {
  background-color: #3b78e6;
  color: white;
  align-self: flex-end;
  text-align: right;
}
.bot-message {
  background-color: #e5e5ea;
  color: black;
  align-self: flex-start;
  text-align: left;
}

@keyframes fadeIn {
  from { opacity: 0; transform: translateY(10px); }
  to { opacity: 1; transform: translateY(0); }
}
</style>
<!-- Footer -->
<footer class="bg-gray-800 text-center py-10 text-gray-400 text-sm mt-20">
  &copy; <?php echo date('Y'); ?> Gamebyte Store. All rights reserved.
</footer>

</body>
</html>
