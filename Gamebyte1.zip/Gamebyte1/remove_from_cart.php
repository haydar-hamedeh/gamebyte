<?php
session_start();

// Check if the product ID is set in the request
if (isset($_POST['product_id'])) {
    $product_id = $_POST['product_id'];

    // Check if the cart exists in the session
    if (isset($_SESSION['cart']) && array_key_exists($product_id, $_SESSION['cart'])) {
        // Remove the product from the cart
        unset($_SESSION['cart'][$product_id]);
    }
}

// Redirect to the cart page
header("Location: cart.php");
exit();
?>
