<?php
session_start();
include('condb.php'); // Ensure you include your database connection

// Check if the admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: admin_login.php');
    exit();
}

// Fetch all categories
$sql = "SELECT * FROM category";
$result = $conn->query($sql);

// Handle category deletion
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_category'])) {
    $category_id = $_POST['category_id'];

    $delete_sql = "DELETE FROM category WHERE category_id = '$category_id'";

    if ($conn->query($delete_sql) === TRUE) {
        $_SESSION['message'] = "Category deleted successfully!";
        header('Location: delete_category.php');
        exit();
    } else {
        $_SESSION['error'] = "Error deleting category: " . $conn->error;
        header('Location: delete_category.php');
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Delete Category</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script> <!-- SweetAlert2 -->
</head>
<body class="bg-gray-900 text-white font-sans">

<?php include('admin_navbar.php'); ?>

<div class="p-10">
    <h2 class="text-3xl font-bold mb-8 text-center">Delete Category</h2>

    <!-- Category Selection Form -->
    <form action="delete_category.php" method="POST">
        <label for="category_id" class="block mb-2">Select Category to Delete:</label>
        <select name="category_id" id="category_id" class="bg-gray-800 text-white p-2 rounded w-full mb-4" required>
            <option value="" disabled selected>Choose a Category</option>
            <?php while ($row = $result->fetch_assoc()): ?>
                <option value="<?= $row['category_id']; ?>"><?= htmlspecialchars($row['category_name']); ?></option>
            <?php endwhile; ?>
        </select>

        <button type="submit" name="delete_category" class="bg-red-500 hover:bg-red-600 text-white p-2 rounded">Delete Category</button>
    </form>
</div>

<!-- SweetAlert2 for Success or Error -->
<?php if (isset($_SESSION['message'])): ?>
<script>
Swal.fire({
    icon: 'success',
    title: 'Success!',
    text: '<?php echo $_SESSION['message']; ?>',
    confirmButtonColor: '#6366F1'
});
</script>
<?php unset($_SESSION['message']); endif; ?>

<?php if (isset($_SESSION['error'])): ?>
<script>
Swal.fire({
    icon: 'error',
    title: 'Oops...',
    text: '<?php echo $_SESSION['error']; ?>',
    confirmButtonColor: '#EF4444'
});
</script>
<?php unset($_SESSION['error']); endif; ?>

</body>
</html>
