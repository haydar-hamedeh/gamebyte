<?php
session_start();
include('condb.php');

// Check if the order was successful
if (!isset($_SESSION['order_id'])) {
    header("Location: index.php"); // Redirect to the homepage if no order ID is set
    exit;
}

$order_id = $_SESSION['order_id'];

// Fetch the order details
$order_sql = "SELECT * FROM orders WHERE order_id = $order_id";
$order_result = $conn->query($order_sql);
$order = $order_result->fetch_assoc();

if (!$order) {
    echo "Order not found!";
    exit;
}

// Fetch order items
$order_items_sql = "SELECT oi.*, p.product_name, p.price FROM order_items oi
                    JOIN products p ON oi.product_id = p.product_id
                    WHERE oi.order_id = $order_id";
$order_items_result = $conn->query($order_items_sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Success</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-b from-black via-gray-800 to-gray-900 text-white font-sans">
    <!-- Include Navbar -->
    <?php include('navbar.php'); ?>

    <!-- Order Success Section -->
    <section id="order-success" class="py-20 text-center">
        <h2 class="text-5xl font-extrabold text-white mb-10">Order Successfully Placed!</h2>
        <p class="text-xl text-white mb-4">Thank you for your order. Your order ID is #<?php echo $order['order_id']; ?>.</p>
        <p class="text-lg text-white mb-4">We will process your order and notify you when it's ready for shipment.</p>

        <!-- Order Summary -->
        <div class="max-w-2xl mx-auto bg-gray-800 p-6 rounded-lg shadow-xl">
            <h3 class="text-3xl font-semibold text-white mb-6">Order Details</h3>
            <p class="text-lg text-white mb-4"><strong>Shipping Address:</strong> <?php echo $order['shipping_address']; ?></p>
            <p class="text-lg text-white mb-4"><strong>Phone Number:</strong> <?php echo $order['phone_number']; ?></p>
            <p class="text-lg text-white mb-4"><strong>Payment Method:</strong> <?php echo ucfirst(str_replace('_', ' ', $order['payment_method'])); ?></p>

            <!-- Order Items -->
            <h4 class="text-2xl text-white mb-4">Items in Your Order</h4>
            <ul class="text-white">
                <?php
                $total = 0;
                while ($order_item = $order_items_result->fetch_assoc()) {
                    $total_price = $order_item['price'] * $order_item['quantity'];
                    $total += $total_price;
                    ?>
                    <li class="mb-4">
                        <span class="font-semibold"><?php echo $order_item['product_name']; ?></span> x <?php echo $order_item['quantity']; ?> - $<?php echo number_format($total_price, 2); ?>
                    </li>
                <?php } ?>
            </ul>
            <div class="text-right mt-6">
                <h4 class="font-semibold text-xl text-white">Total: $<?php echo number_format($total, 2); ?></h4>
            </div>
        </div>

        <p class="text-white mt-8">
            <a href="index.php" class="bg-gradient-to-r from-purple-500 to-indigo-500 text-white hover:bg-gradient-to-l px-6 py-3 rounded-full text-sm font-semibold transition-all duration-300">Go to Homepage</a>
        </p>
    </section>

</body>
</html>
<?php
// Clear the order session
unset($_SESSION['order_id']);
?>
