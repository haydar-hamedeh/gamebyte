<?php
session_start();
include('condb.php');

// Initialize variables
$order_id = '';
$order = null;
$order_items = [];
$error_message = '';
$tracking_id = '';
$success_message = '';

// Handle cancel order request
if (isset($_GET['cancel']) && isset($_GET['order_id'])) {
    $order_id = intval($_GET['order_id']);

    $order_sql = "SELECT * FROM orders WHERE order_id = ? AND customer_id = ? AND status = 'pending'";
    $stmt = $conn->prepare($order_sql);
    $stmt->bind_param('ii', $order_id, $_SESSION['customer_id']);
    $stmt->execute();
    $order_result = $stmt->get_result();

    if ($order_result && $order_result->num_rows > 0) {
        $conn->query("UPDATE orders SET status = 'cancelled' WHERE order_id = $order_id");

        $order_items_sql = "SELECT product_id, quantity FROM order_items WHERE order_id = ?";
        $stmt_items = $conn->prepare($order_items_sql);
        $stmt_items->bind_param('i', $order_id);
        $stmt_items->execute();
        $order_items_result = $stmt_items->get_result();

        while ($item = $order_items_result->fetch_assoc()) {
            $product_id = $item['product_id'];
            $quantity = $item['quantity'];
            $conn->query("UPDATE products SET quantity = quantity + $quantity WHERE product_id = $product_id");
        }

        header("Location: track_order.php?order_id=$order_id&tracking_id=" . urlencode($_GET['tracking_id']));
        exit();
    } else {
        $error_message = "Unable to cancel this order.";
    }
}

// Load order details if coming from checkout
if (isset($_GET['order_id']) && isset($_GET['tracking_id'])) {
    $order_id = intval($_GET['order_id']);
    $tracking_id = htmlspecialchars($_GET['tracking_id']);

    $order_sql = "SELECT * FROM orders WHERE order_id = ? AND customer_id = ?";
    $stmt = $conn->prepare($order_sql);
    $stmt->bind_param('ii', $order_id, $_SESSION['customer_id']);
    $stmt->execute();
    $order_result = $stmt->get_result();

    if ($order_result && $order_result->num_rows > 0) {
        $order = $order_result->fetch_assoc();

        $order_items_sql = "SELECT oi.*, p.product_name, p.price FROM order_items oi
                            JOIN products p ON oi.product_id = p.product_id
                            WHERE oi.order_id = ?";
        $stmt_items = $conn->prepare($order_items_sql);
        $stmt_items->bind_param('i', $order_id);
        $stmt_items->execute();
        $order_items_result = $stmt_items->get_result();

        while ($item = $order_items_result->fetch_assoc()) {
            $order_items[] = $item;
        }
    } else {
        $error_message = "Order not found.";
    }
}

// If tracking manually by form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $order_id = $_POST['order_id'];

    $order_sql = "SELECT * FROM orders WHERE order_id = ? AND customer_id = ?";
    $stmt = $conn->prepare($order_sql);
    $stmt->bind_param('ii', $order_id, $_SESSION['customer_id']);
    $stmt->execute();
    $order_result = $stmt->get_result();

    if ($order_result && $order_result->num_rows > 0) {
        $order = $order_result->fetch_assoc();
        $success_message = "Order found!";

        $order_items_sql = "SELECT oi.*, p.product_name, p.price FROM order_items oi
                            JOIN products p ON oi.product_id = p.product_id
                            WHERE oi.order_id = ?";
        $stmt_items = $conn->prepare($order_items_sql);
        $stmt_items->bind_param('i', $order_id);
        $stmt_items->execute();
        $order_items_result = $stmt_items->get_result();

        while ($item = $order_items_result->fetch_assoc()) {
            $order_items[] = $item;
        }
    } else {
        $error_message = "Order not found. Please check the order ID and try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Track Your Order</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script> <!-- SweetAlert2 -->
</head>
<body class="bg-gradient-to-b from-black via-gray-800 to-gray-900 text-white font-sans">

<?php include('navbar.php'); ?>

<section id="order-tracking" class="py-20 text-center">
    <h2 class="text-5xl font-extrabold text-white mb-10">Track Your Order</h2>

    <!-- Always visible form -->
    <form action="track_order.php" method="POST" class="max-w-md mx-auto bg-gray-800 p-6 rounded-lg shadow-xl mb-10">
        <label for="order_id" class="block text-lg text-white mb-4">Enter Your Order ID:</label>
        <input type="text" id="order_id" name="order_id" class="w-full p-2 mb-4 bg-gray-700 text-white rounded" required>
        <button type="submit" class="bg-gradient-to-r from-purple-500 to-indigo-500 text-white hover:bg-gradient-to-l px-6 py-3 rounded-full text-sm font-semibold transition-all duration-300 mt-4 inline-block">
            Track Order
        </button>
    </form>

    <!-- Display Order Details if found -->
    <?php if (!empty($order)): ?>
        <div class="max-w-2xl mx-auto bg-gray-800 p-6 rounded-lg shadow-xl mt-10">
            <h3 class="text-3xl font-semibold text-white mb-6">Order Details for Order ID: #<?php echo $order['order_id']; ?></h3>
            <p class="text-lg text-white mb-4"><strong>Tracking ID:</strong> <?php echo htmlspecialchars($order['tracking_id']); ?></p>
            <p class="text-lg text-white mb-4"><strong>Shipping Address:</strong> <?php echo htmlspecialchars($order['shipping_address']); ?></p>
            <p class="text-lg text-white mb-4"><strong>Phone Number:</strong> <?php echo htmlspecialchars($order['phone_number']); ?></p>
            <p class="text-lg text-white mb-4"><strong>Payment Method:</strong> <?php echo ucfirst(str_replace('_', ' ', $order['payment_method'])); ?></p>
            <p class="text-lg text-white mb-4">
                <strong>Order Status:</strong>
                <?php 
                    $status = strtolower($order['status']);
                    if ($status == 'pending') {
                        echo "<span class='text-yellow-400 font-semibold capitalize'>$status</span>";
                    } elseif ($status == 'delivering') {
                        echo "<span class='text-blue-400 font-semibold capitalize'>$status</span>";
                    } elseif ($status == 'delivered') {
                        echo "<span class='text-green-400 font-semibold capitalize'>$status</span>";
                    } elseif ($status == 'cancelled') {
                        echo "<span class='text-red-400 font-semibold capitalize'>$status</span>";
                    } else {
                        echo "<span class='text-gray-400 font-semibold capitalize'>$status</span>";
                    }
                ?>
            </p>

            <!-- Cancel Order Button if Pending -->
            <?php if (strtolower($order['status']) == 'pending'): ?>
                <button onclick="confirmCancel(<?php echo $order['order_id']; ?>, '<?php echo urlencode($order['tracking_id']); ?>')" 
                        class="inline-block bg-red-600 hover:bg-red-700 text-white px-6 py-2 rounded-full text-sm font-semibold transition-all duration-300 mt-6">
                    Cancel Order
                </button>
            <?php endif; ?>

            <!-- Order Items -->
            <h4 class="text-2xl text-white mb-4 mt-8">Items in Your Order</h4>
            <ul class="text-white">
                <?php
                $total = 0;
                foreach ($order_items as $order_item) {
                    $total_price = $order_item['price'] * $order_item['quantity'];
                    $total += $total_price;
                ?>
                    <li class="mb-4">
                        <span class="font-semibold"><?php echo htmlspecialchars($order_item['product_name']); ?></span> x <?php echo $order_item['quantity']; ?> - $<?php echo number_format($total_price, 2); ?>
                    </li>
                <?php } ?>
            </ul>
            <div class="text-right mt-6">
                <h4 class="font-semibold text-xl text-white">Total: $<?php echo number_format($total, 2); ?></h4>
            </div>
        </div>
    <?php endif; ?>

    <?php if (!empty($error_message)): ?>
        <script>
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: '<?php echo $error_message; ?>'
            });
        </script>
    <?php elseif (!empty($success_message)): ?>
        <script>
            Swal.fire({
                icon: 'success',
                title: 'Success!',
                text: '<?php echo $success_message; ?>'
            });
        </script>
    <?php endif; ?>

</section>

<!-- SweetAlert2 Cancel Order -->
<script>
function confirmCancel(orderId, trackingId) {
    Swal.fire({
        title: 'Cancel Order?',
        text: "Are you sure you want to cancel this order? This action cannot be undone!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Yes, cancel it!'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = `track_order.php?cancel=1&order_id=${orderId}&tracking_id=${trackingId}`;
        }
    });
}
</script>

</body>
</html>
