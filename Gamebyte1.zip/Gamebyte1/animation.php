<!-- Loading Spinner Overlay -->
<div id="page-loader" class="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50 hidden">
    <div class="loader" style="width: 60px; height: 60px; border-width: 6px;"></div>
</div>

<!-- Loader CSS -->
<style>
.loader {
  border: 6px solid rgba(255, 255, 255, 0.3);
  border-top-color: #ffffff;
  border-radius: 50%;
  animation: spin 1s linear infinite;
}
@keyframes spin {
  to { transform: rotate(360deg); }
}
</style>

<!-- Loader JavaScript -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const loader = document.getElementById('page-loader');

    // Hide loader once page is loaded
    window.addEventListener('load', function() {
        loader.classList.add('hidden');
    });

    // Show loader when clicking any <a> link
    document.querySelectorAll('a').forEach(link => {
        link.addEventListener('click', function(e) {
            const href = link.getAttribute('href');
            if (href && !href.startsWith('#') && !href.startsWith('javascript') && link.target !== "_blank") {
                e.preventDefault(); // Stop immediate navigation
                loader.classList.remove('hidden'); // Show the loader

                setTimeout(() => {
                    window.location.href = href; // After small delay, go to link
                }, 500); // 500 milliseconds = half second loading
            }
        });
    });

    // OPTIONAL: If you want same for buttons
    document.querySelectorAll('button[type="submit"]').forEach(button => {
        button.addEventListener('click', function() {
            loader.classList.remove('hidden');
        });
    });
});
</script>
