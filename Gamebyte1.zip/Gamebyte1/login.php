<?php
include('condb.php');
session_start();

if (isset($_POST['login'])) {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    $sql = "SELECT * FROM customer WHERE email = '$email'";
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();

        if (password_verify($password, $row['password'])) {
            // ✅ Store essential session data
            $_SESSION['customer_id'] = $row['customer_id'];
            $_SESSION['customer_username'] = $row['customer_username'];
            $_SESSION['customer_email'] = $row['email'];
            $_SESSION['customer_phone'] = $row['phone'];
            $_SESSION['customer_address'] = $row['address'];

            // ✅ Restore Cart
            $customer_id = $row['customer_id'];
            $cart_sql = "SELECT ci.product_id, ci.quantity, p.product_name, p.price, p.image
                         FROM cart_items ci
                         JOIN products p ON ci.product_id = p.product_id
                         WHERE ci.customer_id = $customer_id";
            $cart_result = $conn->query($cart_sql);

            if ($cart_result && $cart_result->num_rows > 0) {
                $_SESSION['cart'] = [];
                while ($item = $cart_result->fetch_assoc()) {
                    $_SESSION['cart'][$item['product_id']] = [
                        'product_name' => $item['product_name'],
                        'price' => $item['price'],
                        'image' => $item['image'],
                        'quantity' => $item['quantity']
                    ];
                }
            }

            header("Location: index.php");
            exit();
        } else {
            $_SESSION['error'] = "Incorrect password. Please try again.";
        }
    } else {
        $_SESSION['error'] = "Email not found. Please sign up first.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Login | Gamebyte Store</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    @keyframes fadeSlideIn {
      0% { transform: translateY(30px); opacity: 0; }
      100% { transform: translateY(0); opacity: 1; }
    }
    @keyframes shake {
      0%, 100% { transform: translateX(0); }
      20%, 60% { transform: translateX(-10px); }
      40%, 80% { transform: translateX(10px); }
    }
    .animate-fadeSlideIn { animation: fadeSlideIn 0.8s ease-out forwards; }
    .animate-shake { animation: shake 0.5s; }
    .input-focus:focus {
      outline: none;
      border-color: #9333ea;
      box-shadow: 0 0 10px rgba(147, 51, 234, 0.6);
    }
  </style>
</head>

<body class="bg-gradient-to-b from-black via-gray-900 to-gray-800 text-white min-h-screen flex flex-col">

  <?php include('navbar.php'); ?>

  <!-- Login Section -->
  <section class="flex-1 flex items-center justify-center p-6">
    <div class="w-full max-w-md bg-gray-800 p-8 rounded-2xl shadow-2xl animate-fadeSlideIn <?php if(isset($_SESSION['error'])) echo 'animate-shake'; ?>">
      <h2 class="text-4xl font-bold text-center mb-8">Welcome Back</h2>

      <!-- Error Message -->
      <?php if (isset($_SESSION['error'])): ?>
        <div class="bg-red-600 text-white p-4 rounded mb-6 text-center">
          <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
        </div>
      <?php endif; ?>

      <form action="login.php" method="POST" class="space-y-6">
        <div>
          <label for="email" class="block text-sm font-semibold mb-2">Email Address</label>
          <input type="email" id="email" name="email"
            class="w-full px-4 py-3 bg-gray-700 rounded-lg input-focus" required
            value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
        </div>

        <div>
          <label for="password" class="block text-sm font-semibold mb-2">Password</label>
          <input type="password" id="password" name="password"
            class="w-full px-4 py-3 bg-gray-700 rounded-lg input-focus" required>
        </div>

        <button type="submit" name="login"
          class="w-full py-3 bg-gradient-to-r from-purple-600 to-indigo-600 rounded-lg text-lg font-semibold transition-transform transform hover:scale-105 duration-300">
          Log In
        </button>
      </form>

      <p class="text-sm text-center text-gray-400 mt-6">Don't have an account?
        <a href="signup.php" class="text-purple-400 hover:underline">Sign up</a>.
      </p>
    </div>
  </section>

  <!-- Footer -->
  <footer class="text-center p-6 text-gray-500 text-sm">
    &copy; <?php echo date('Y'); ?> Gamebyte Store
  </footer>

</body>
</html>
