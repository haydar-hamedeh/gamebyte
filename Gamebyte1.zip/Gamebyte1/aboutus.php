<?php
include('condb.php');
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>About Us | Gamebyte Store</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gradient-to-b from-black via-gray-800 to-gray-900 text-white font-sans">

  <!-- Include Navbar -->
  <?php include('navbar.php'); ?>

  <!-- About Us Section -->
  <section id="about-us-header" class="py-20 text-center">
    <h1 class="text-5xl font-extrabold text-white mb-4">About Gamebyte Store</h1>
    <p class="text-lg text-gray-400">Your go-to destination for gaming products and accessories</p>
  </section>

  <!-- Company Introduction -->
  <section id="company-intro" class="py-20 px-4">
    <div class="container mx-auto text-center">
      <h2 class="text-4xl font-extrabold text-white mb-6">Who We Are</h2>
      <p class="text-lg text-gray-400 max-w-2xl mx-auto">
        Gamebyte Store is your one-stop shop for everything gaming. We are passionate about gaming and provide the latest gaming products, consoles, and accessories. Our mission is to offer gamers the best products at unbeatable prices, so you can focus on what really matters—your gaming experience.
      </p>
    </div>
  </section>

  <!-- Our Mission -->
  <section id="mission" class="py-20 bg-gray-800">
    <div class="container mx-auto text-center">
      <h2 class="text-4xl font-extrabold text-white mb-6">Our Mission</h2>
      <p class="text-lg text-gray-400 max-w-2xl mx-auto">
        At Gamebyte Store, our mission is to empower gamers everywhere by providing high-quality gaming products and a seamless shopping experience. Whether you're a casual gamer or a competitive pro, we aim to cater to your gaming needs and enhance your gaming journey with the best gear on the market.
      </p>
    </div>
  </section>

  <!-- Google Maps Location -->
  <section id="google-maps-location" class="py-20 px-4">
    <div class="container mx-auto text-center">
      <h2 class="text-4xl font-extrabold text-white mb-6">Find Us Here</h2>
      <p class="text-lg text-gray-400 mb-6">Our physical store location is shown below. Feel free to visit us!</p>

      <!-- Google Map Embed -->
      <div class="w-full h-96">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3153.301017125665!2d-122.41941648468124!3d37.77492927975944!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8085808b2b7f43f5%3A0x4735c5e1234e74e2!2sGamebyte%20Store%2C%20San%20Francisco!5e0!3m2!1sen!2sus!4v1672949296223!5m2!1sen!2sus" width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
      </div>
    </div>
  </section>

  <!-- Contact Us -->
  <section id="contact-us" class="py-20 bg-gray-900">
    <div class="container mx-auto text-center">
      <h2 class="text-4xl font-extrabold text-white mb-6">Contact Us</h2>
      <p class="text-lg text-gray-400 mb-6">Have questions? We'd love to hear from you! Reach out to us through the following channels.</p>
      <div class="space-y-4">
        <p class="text-lg text-gray-400"><strong>Email:</strong> support@gamebytestore.com</p>
        <p class="text-lg text-gray-400"><strong>Phone:</strong> +1 (123) 456-7890</p>
        <p class="text-lg text-gray-400"><strong>Address:</strong> 123 Gaming St., New York, NY</p>
      </div>
    </div>
  </section>
 <!-- Floating Chatbot Button -->
<div id="chatbot-toggle" style="position: fixed; bottom: 30px; right: 30px; background-color: #3b78e6; color: white; border: none; border-radius: 50%; width: 60px; height: 60px; font-size: 24px; display: flex; justify-content: center; align-items: center; cursor: pointer; z-index: 9999;">
  💬
</div>

<!-- Chatbot Window -->
<div id="chatbot-window" class="hidden chatbot-window-style">
  <div class="chatbot-header">GameByte Chatbot</div>
  <div id="chat-content" class="chatbot-content"></div>
  <div class="chatbot-input-area">
    <input type="text" id="user-message" placeholder="Type a message..." class="chatbot-input">
  </div>
</div>

<!-- Chatbot Script -->
<script>
const toggleBtn = document.getElementById('chatbot-toggle');
const chatWindow = document.getElementById('chatbot-window');
const userInput = document.getElementById('user-message');
const chatContent = document.getElementById('chat-content');

toggleBtn.addEventListener('click', () => {
  if (chatWindow.classList.contains('hidden')) {
    chatWindow.classList.remove('hidden');
    setTimeout(() => {
      chatWindow.style.transform = 'scale(1)';
      chatWindow.style.opacity = '1';
    }, 10);
  } else {
    chatWindow.style.transform = 'scale(0)';
    chatWindow.style.opacity = '0';
    setTimeout(() => {
      chatWindow.classList.add('hidden');
    }, 300);
  }
});

userInput.addEventListener('keypress', function(e) {
  if (e.key === 'Enter' && userInput.value.trim() !== '') {
    const userMsg = userInput.value.trim();
    displayMessage(userMsg, 'user');
    userInput.value = '';

    fetch('/GameByte1/chatbot.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: userMsg })
    })
    .then(response => response.json())
    .then(data => {
      const botReply = data.reply;
      displayMessage(botReply, 'bot');
    })
    .catch(error => {
      console.error('Error:', error);
      displayMessage('Sorry, something went wrong.', 'bot');
    });
  }
});

function displayMessage(message, sender) {
  const messageDiv = document.createElement('div');
  messageDiv.classList.add('message');
  messageDiv.classList.add(sender === 'user' ? 'user-message' : 'bot-message');
  messageDiv.innerText = message;
  chatContent.appendChild(messageDiv);
  chatContent.scrollTop = chatContent.scrollHeight;
}
</script>

<!-- Chatbot Styles -->
<style>
/* Full Chatbot Window */
.chatbot-window-style {
  position: fixed;
  bottom: 100px;
  right: 30px;
  width: 320px;
  height: 400px;
  background: #fff;
  border-radius: 15px;
  box-shadow: 0 4px 15px rgba(0,0,0,0.3);
  z-index: 9999;
  flex-direction: column;
  overflow: hidden;
  transform: scale(0);
  opacity: 0;
  transition: all 0.3s ease;
  display: flex;
}

/* Chatbot header */
.chatbot-header {
  background-color: #3b78e6;
  color: white;
  padding: 12px;
  font-weight: bold;
  text-align: center;
  font-size: 18px;
  border-top-left-radius: 15px;
  border-top-right-radius: 15px;
}

/* Messages area */
.chatbot-content {
  flex: 1;
  padding: 10px;
  overflow-y: auto;
  font-size: 14px;
  display: flex;
  flex-direction: column;
  gap: 10px;
  background: #f9f9f9;
}

/* Input area */
.chatbot-input-area {
  padding: 10px;
  border-top: 1px solid #ddd;
  background: #f1f0f0;
}

/* Input field */
.chatbot-input {
  width: 100%;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 10px;
  font-size: 14px;
  outline: none;
  background: white;
  color: black;
}
.chatbot-input:focus {
  border-color: #3b78e6;
}

/* Message Styles */
.message {
  max-width: 70%;
  padding: 8px 12px;
  border-radius: 20px;
  animation: fadeIn 0.5s;
}
.user-message {
  background-color: #3b78e6;
  color: white;
  align-self: flex-end;
  text-align: right;
}
.bot-message {
  background-color: #e5e5ea;
  color: black;
  align-self: flex-start;
  text-align: left;
}

@keyframes fadeIn {
  from { opacity: 0; transform: translateY(10px); }
  to { opacity: 1; transform: translateY(0); }
}
</style>


  <!-- Footer -->
  <footer class="bg-gray-800 text-center py-10 text-gray-400 text-sm">
    &copy; <?php echo date('Y'); ?> Gamebyte Store. All rights reserved.
  </footer>

</body>

</html>
