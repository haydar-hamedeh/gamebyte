<?php
session_start();
include('condb.php');

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $subcategory_name = mysqli_real_escape_string($conn, $_POST['subcategory_name']);
    $category_id = intval($_POST['category_id']);

    if (!empty($subcategory_name) && $category_id > 0) {
        $insert = "INSERT INTO subcategory (subcategory_name, category_id) VALUES ('$subcategory_name', $category_id)";
        if ($conn->query($insert)) {
            $_SESSION['message'] = "Subcategory added successfully!";
            header('Location: add_subcategory.php');
            exit();
        } else {
            $_SESSION['error'] = "Error adding subcategory: " . $conn->error;
            header('Location: add_subcategory.php');
            exit();
        }
    } else {
        $_SESSION['error'] = "Please fill in all fields.";
        header('Location: add_subcategory.php');
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Subcategory</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script> <!-- SweetAlert2 -->
</head>
<body class="bg-gray-900 text-white font-sans min-h-screen">
    <?php include('admin_navbar.php'); ?>

    <div class="flex items-center justify-center py-16">
        <div class="bg-gray-800 p-10 rounded-lg shadow-lg w-full max-w-md">
            <h2 class="text-2xl font-bold mb-6 text-center">Add Subcategory</h2>

            <form method="POST" action="" class="space-y-6">
                <div>
                    <label for="subcategory_name" class="block mb-2">Subcategory Name</label>
                    <input type="text" name="subcategory_name" id="subcategory_name" required
                           class="w-full px-4 py-2 rounded bg-gray-700 focus:outline-none focus:ring-2 focus:ring-purple-500">
                </div>

                <div>
                    <label for="category_id" class="block mb-2">Select Category</label>
                    <select name="category_id" id="category_id" required
                            class="w-full px-4 py-2 rounded bg-gray-700 focus:outline-none focus:ring-2 focus:ring-purple-500">
                        <option value="">Select a category</option>
                        <?php
                        $categories = $conn->query("SELECT * FROM category");
                        while ($cat = $categories->fetch_assoc()):
                        ?>
                            <option value="<?php echo $cat['category_id']; ?>">
                                <?php echo htmlspecialchars($cat['category_name']); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>

                <button type="submit" class="w-full bg-purple-600 hover:bg-purple-700 px-4 py-2 rounded font-bold">
                    Add Subcategory
                </button>
            </form>
        </div>
    </div>

    <!-- SweetAlert2 for Success or Error -->
    <?php if (isset($_SESSION['message'])): ?>
    <script>
    Swal.fire({
        icon: 'success',
        title: 'Success!',
        text: '<?php echo $_SESSION['message']; ?>',
        confirmButtonColor: '#6366F1'
    });
    </script>
    <?php unset($_SESSION['message']); endif; ?>

    <?php if (isset($_SESSION['error'])): ?>
    <script>
    Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: '<?php echo $_SESSION['error']; ?>',
        confirmButtonColor: '#EF4444'
    });
    </script>
    <?php unset($_SESSION['error']); endif; ?>
</body>
</html>
