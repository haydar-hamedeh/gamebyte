<?php
include('condb.php');

if (isset($_GET['category_id'])) {
    $category_id = intval($_GET['category_id']);
    $subcategories = [];

    $sql = "SELECT * FROM subcategory WHERE category_id = $category_id";
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $subcategories[] = $row;
        }
    }

    echo json_encode($subcategories);
}
?>
