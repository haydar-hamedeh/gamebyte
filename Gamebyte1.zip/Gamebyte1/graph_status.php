<?php
session_start();
include('condb.php');

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: admin_login.php');
    exit();
}

// Fetch order statuses count
$status_counts = [
    'pending' => 0,
    'delivering' => 0,
    'delivered' => 0,
    'cancelled' => 0
];

$sql = "SELECT status, COUNT(*) as count FROM orders GROUP BY status";
$result = $conn->query($sql);

while ($row = $result->fetch_assoc()) {
    $status = strtolower($row['status']);
    if (isset($status_counts[$status])) {
        $status_counts[$status] = $row['count'];
    }
}

// Calculate total orders
$total_orders = array_sum($status_counts);

// Calculate percentages safely
function getPercentage($count, $total) {
    if ($total == 0) return 0;
    return round(($count / $total) * 100);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Order Status Graph</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script> <!-- Chart.js -->
</head>
<body class="bg-gray-900 text-white min-h-screen">

<?php include('admin_navbar.php'); ?>

<div class="container mx-auto p-8">
    <h1 class="text-3xl font-bold mb-8 text-center">Order Status Overview</h1>

    <div class="flex justify-center mb-12">
        <div class="w-96 h-96">
            <canvas id="statusChart"></canvas>
        </div>
    </div>

    <!-- Analysis Section -->
    <div class="bg-gray-800 p-6 rounded-lg shadow-lg text-center">
        <h2 class="text-2xl font-bold mb-4">📊 Detailed Analysis</h2>

        <div class="text-xl mb-4">
            Total Orders: <span class="text-green-400 font-bold"><?php echo $total_orders; ?></span>
        </div>

        <!-- Statuses Grid -->
        <div class="space-y-8 mt-8">

            <!-- Pending -->
            <div>
                <div class="flex justify-between mb-2">
                    <span class="text-yellow-400 font-semibold">Pending</span>
                    <span><?php echo $status_counts['pending']; ?> (<?php echo getPercentage($status_counts['pending'], $total_orders); ?>%)</span>
                </div>
                <div class="w-full bg-gray-700 rounded-full h-4 overflow-hidden">
                    <div class="bg-yellow-400 h-4 rounded-full" style="width: <?php echo getPercentage($status_counts['pending'], $total_orders); ?>%;"></div>
                </div>
            </div>

            <!-- Delivering -->
            <div>
                <div class="flex justify-between mb-2">
                    <span class="text-blue-400 font-semibold">Delivering</span>
                    <span><?php echo $status_counts['delivering']; ?> (<?php echo getPercentage($status_counts['delivering'], $total_orders); ?>%)</span>
                </div>
                <div class="w-full bg-gray-700 rounded-full h-4 overflow-hidden">
                    <div class="bg-blue-400 h-4 rounded-full" style="width: <?php echo getPercentage($status_counts['delivering'], $total_orders); ?>%;"></div>
                </div>
            </div>

            <!-- Delivered -->
            <div>
                <div class="flex justify-between mb-2">
                    <span class="text-green-400 font-semibold">Delivered</span>
                    <span><?php echo $status_counts['delivered']; ?> (<?php echo getPercentage($status_counts['delivered'], $total_orders); ?>%)</span>
                </div>
                <div class="w-full bg-gray-700 rounded-full h-4 overflow-hidden">
                    <div class="bg-green-400 h-4 rounded-full" style="width: <?php echo getPercentage($status_counts['delivered'], $total_orders); ?>%;"></div>
                </div>
            </div>

            <!-- Cancelled -->
            <div>
                <div class="flex justify-between mb-2">
                    <span class="text-red-400 font-semibold">Cancelled</span>
                    <span><?php echo $status_counts['cancelled']; ?> (<?php echo getPercentage($status_counts['cancelled'], $total_orders); ?>%)</span>
                </div>
                <div class="w-full bg-gray-700 rounded-full h-4 overflow-hidden">
                    <div class="bg-red-400 h-4 rounded-full" style="width: <?php echo getPercentage($status_counts['cancelled'], $total_orders); ?>%;"></div>
                </div>
            </div>

        </div>
    </div>

</div>

<script>
const ctx = document.getElementById('statusChart').getContext('2d');
const statusChart = new Chart(ctx, {
    type: 'pie',
    data: {
        labels: ['Pending', 'Delivering', 'Delivered', 'Cancelled'],
        datasets: [{
            label: 'Order Status',
            data: [
                <?php echo $status_counts['pending']; ?>,
                <?php echo $status_counts['delivering']; ?>,
                <?php echo $status_counts['delivered']; ?>,
                <?php echo $status_counts['cancelled']; ?>
            ],
            backgroundColor: [
                '#f59e0b', // Pending
                '#3b82f6', // Delivering
                '#10b981', // Delivered
                '#ef4444'  // Cancelled
            ],
            borderColor: '#1f2937', // Dark gray
            borderWidth: 2
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: {
                position: 'bottom',
                labels: {
                    color: 'white',
                    font: {
                        size: 14
                    }
                }
            },
            title: {
                display: true,
                text: 'Order Status Distribution',
                color: 'white',
                font: {
                    size: 20
                }
            }
        }
    }
});
</script>

</body>
</html>
