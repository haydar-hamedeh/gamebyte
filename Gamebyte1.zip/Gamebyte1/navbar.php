<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
include('condb.php');
?>
<div class="w-full bg-gradient-to-r from-pink-500 to-yellow-500 text-center text-white font-bold py-2 animate-pulse">
  🎮 Big Sale! Up to 20% OFF on selected products + Free Shipping! 🚚
</div>

<nav class="flex items-center justify-between p-6 bg-gradient-to-r from-purple-600 to-indigo-700 shadow-lg animate-fadeIn">
  <div class="flex items-center space-x-4">
    <img src="uploads/gamebyte.png" alt="Gamebyte Logo" class="w-12 h-12 rounded-full animate-pulseFast">
    <a href="index.php">
      <span class="text-3xl font-extrabold tracking-wide text-white">Gamebyte Store</span>
    </a>
  </div>

  <div class="flex items-center space-x-6">
    <div class="relative">
      <input id="search-input" type="text" placeholder="Search products..." 
        class="w-72 pl-12 pr-4 py-2 rounded-full border-none bg-gray-700 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500">
      <img src="https://img.icons8.com/ios-filled/24/ffffff/search--v1.png" 
        class="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 pointer-events-none" />
      <div id="search-results" 
        class="absolute w-72 bg-white text-black rounded-lg shadow-lg mt-2 hidden max-h-60 overflow-y-auto z-50"></div>
    </div>
  </div>

  <div class="hidden md:flex space-x-10 text-lg items-center">
    <a href="index.php" class="hover:text-purple-400 transition-all duration-300">Home</a>
    <a href="store.php" class="hover:text-purple-400 transition-all duration-300">Store</a>
    <a href="aboutus.php" class="hover:text-purple-400 transition-all duration-300">About Us</a>

    <!-- Categories Dropdown -->
    <div class="relative">
      <button id="categories-button" class="flex items-center text-white hover:text-purple-400 transition-all duration-300 focus:outline-none">
        <span>Categories</span>
        <svg id="chevron-icon" class="w-4 h-4 ml-2 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
        </svg>
      </button>
      <div id="categories-menu" class="absolute left-0 mt-2 bg-gray-800 rounded-lg shadow-lg hidden z-50">
        <ul class="text-white p-2 w-48">
          <?php
          $sql = "SELECT * FROM category";
          $result = $conn->query($sql);

          if ($result->num_rows > 0) {
              while ($row = $result->fetch_assoc()) {
                  // Check if category has subcategories
                  $sub_sql = "SELECT * FROM subcategory WHERE category_id = " . $row['category_id'];
                  $sub_result = $conn->query($sub_sql);
                  $has_subcategories = $sub_result->num_rows > 0;

                  echo "<li class='relative'>";
                  if ($has_subcategories) {
                      echo "<button type='button' class='flex justify-between items-center w-full hover:bg-purple-600 px-4 py-2 rounded focus:outline-none' onclick='toggleSubmenu(this)'>";
                      echo htmlspecialchars($row['category_name']) . "<span class='ml-2'>▼</span>";
                      echo "</button>";
                      echo "<ul class='hidden flex-col bg-gray-700 rounded-lg shadow-lg mt-2'>";
                      while ($sub = $sub_result->fetch_assoc()) {
                          echo "<li><a href='subcategory.php?subcategory_id=" . $sub['subcategory_id'] . "' class='block hover:bg-purple-600 px-4 py-2 rounded'>" . htmlspecialchars($sub['subcategory_name']) . "</a></li>";
                      }
                      echo "</ul>";
                  } else {
                      echo "<a href='category.php?category_id=" . $row['category_id'] . "' class='block hover:bg-purple-600 px-4 py-2 rounded'>" . htmlspecialchars($row['category_name']) . "</a>";
                  }
                  echo "</li>";
              }
          } else {
              echo "<li class='px-4 py-2'>No categories available</li>";
          }
          ?>
        </ul>
      </div>
    </div>

    <?php if (isset($_SESSION['customer_id'])): ?>
      <a href="track_order.php" class="hover:text-purple-400 transition-all duration-300">Track Order</a>
    <?php endif; ?>

    <div class="relative flex items-center cursor-pointer ml-6" id="cart-icon">
      <img src="https://img.icons8.com/ios-filled/24/ffffff/shopping-cart.png" alt="Cart" class="w-8 h-8">
      <div class="absolute -top-2 -right-2 bg-red-500 text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
        <?php echo isset($_SESSION['cart']) ? count($_SESSION['cart']) : "0"; ?>
      </div>
    </div>

    <?php if (!isset($_SESSION['customer_id'])): ?>
      <a href="signup.php" class="bg-gradient-to-r from-purple-500 to-indigo-500 hover:bg-gradient-to-l px-6 py-3 rounded-full text-sm font-semibold transition-all duration-300 ml-4">Sign Up</a>
      <a href="login.php" class="bg-gradient-to-r from-green-500 to-teal-500 hover:bg-gradient-to-l px-6 py-3 rounded-full text-sm font-semibold transition-all duration-300 ml-2">Login</a>
    <?php else: ?>
      <a href="logout.php" class="bg-gradient-to-r from-red-500 to-indigo-500 hover:bg-gradient-to-l px-6 py-3 rounded-full text-sm font-semibold transition-all duration-300 ml-4">Logout</a>
    <?php endif; ?>
  </div>
</nav>

<!-- JavaScript Section -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('search-input');
    const searchResults = document.getElementById('search-results');

    searchInput.addEventListener('input', function() {
        const query = this.value.trim();
        if (query.length > 0) {
            fetch('search.php?query=' + encodeURIComponent(query))
                .then(response => response.json())
                .then(data => {
                    if (data.length > 0) {
                        searchResults.innerHTML = data.map(product => `
                            <a href="product.php?id=${product.product_id}" class="flex items-center space-x-4 p-2 hover:bg-gray-100 rounded-lg transition">
                                <img src="${product.image}" onerror="this.src='uploads/default-image.png'" class="w-14 h-14 object-cover rounded-md" alt="${product.name}">
                                <div class="flex flex-col">
                                    <span class="font-semibold text-gray-800">${product.name}</span>
                                    <span class="text-sm text-gray-500">$${product.price}</span>
                                </div>
                            </a>
                        `).join('');
                        searchResults.classList.remove('hidden');
                    } else {
                        searchResults.innerHTML = '<div class="p-2 text-gray-600">No products found.</div>';
                        searchResults.classList.remove('hidden');
                    }
                })
                .catch(error => {
                    console.error('Error fetching products:', error);
                });
        } else {
            searchResults.classList.add('hidden');
            searchResults.innerHTML = '';
        }
    });

    document.addEventListener('click', function(event) {
        if (!searchResults.contains(event.target) && !searchInput.contains(event.target)) {
            searchResults.classList.add('hidden');
        }
    });

    // Cart icon behavior
    document.getElementById('cart-icon').addEventListener('click', function () {
        <?php if (!isset($_SESSION['customer_id'])) { ?>
            alert("You must sign up or log in to access the cart.");
            window.location.href = "signup.php";
        <?php } else { ?>
            window.location.href = "cart.php";
        <?php } ?>
    });

    // Toggle submenus
    window.toggleSubmenu = function(button) {
        const allSubmenus = document.querySelectorAll("#categories-menu ul ul");
        allSubmenus.forEach(ul => {
            if (ul !== button.nextElementSibling) {
                ul.classList.add('hidden');
            }
        });

        const submenu = button.nextElementSibling;
        if (submenu) {
            submenu.classList.toggle('hidden');
        }
    };

    // Categories menu main toggle
    const categoriesButton = document.getElementById('categories-button');
    const categoriesMenu = document.getElementById('categories-menu');
    const chevronIcon = document.getElementById('chevron-icon');

    categoriesButton.addEventListener('click', function(event) {
        event.stopPropagation();
        categoriesMenu.classList.toggle('hidden');
        chevronIcon.classList.toggle('rotate-180');
    });

    document.addEventListener('click', function(event) {
        if (!categoriesButton.contains(event.target) && !categoriesMenu.contains(event.target)) {
            categoriesMenu.classList.add('hidden');
            chevronIcon.classList.remove('rotate-180');
        }
    });
});
</script>
