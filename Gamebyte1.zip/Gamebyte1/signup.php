<?php
include('condb.php');
session_start();

if (isset($_POST['signup'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $confirm_password = mysqli_real_escape_string($conn, $_POST['confirm_password']);

    if (strlen($password) < 8 || !preg_match('/[A-Z]/', $password) || !preg_match('/[a-z]/', $password) || !preg_match('/[^a-zA-Z\d]/', $password)) {
        $_SESSION['error'] = "Password must be at least 8 characters long, and include at least one uppercase letter, one lowercase letter, and one special character.";
    } elseif ($password != $confirm_password) {
        $_SESSION['error'] = "Passwords do not match!";
    } else {
        $check_email = "SELECT * FROM customer WHERE email = '$email'";
        $result = $conn->query($check_email);
        if ($result->num_rows > 0) {
            $_SESSION['error'] = "Email already exists. Please use a different email.";
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $sql = "INSERT INTO customer (customer_username, email, password) VALUES ('$username', '$email', '$hashed_password')";
            if ($conn->query($sql) === TRUE) {
                $_SESSION['success'] = "Account created successfully! Please log in.";
                header("Location: login.php");
                exit();
            } else {
                $_SESSION['error'] = "Error: " . $conn->error;
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sign Up | Gamebyte Store</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    /* Custom Animations */
    @keyframes fadeSlideIn {
      0% { transform: translateY(30px); opacity: 0; }
      100% { transform: translateY(0); opacity: 1; }
    }
    @keyframes shake {
      0%, 100% { transform: translateX(0); }
      20%, 60% { transform: translateX(-10px); }
      40%, 80% { transform: translateX(10px); }
    }
    .animate-fadeSlideIn { animation: fadeSlideIn 0.8s ease-out forwards; }
    .animate-shake { animation: shake 0.5s; }
    .input-focus:focus {
      outline: none;
      border-color: #9333ea;
      box-shadow: 0 0 10px rgba(147, 51, 234, 0.6);
    }
  </style>
</head>

<body class="bg-gradient-to-b from-black via-gray-900 to-gray-800 text-white min-h-screen flex flex-col">

  <!-- Navbar -->
  <?php include('navbar.php'); ?>

  <!-- Signup Section -->
  <section id="signup-section" class="flex-1 flex items-center justify-center p-6">
    <div class="w-full max-w-md bg-gray-800 p-8 rounded-2xl shadow-2xl animate-fadeSlideIn <?php if(isset($_SESSION['error'])) echo 'animate-shake'; ?>">
      <h2 class="text-4xl font-bold text-center mb-8">Create Your Account</h2>

      <!-- Error Message -->
      <?php if (isset($_SESSION['error'])): ?>
        <div class="bg-red-600 text-white p-4 rounded mb-6 text-center">
          <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
        </div>
      <?php endif; ?>

      <!-- Success Message -->
      <?php if (isset($_SESSION['success'])): ?>
        <div class="bg-green-600 text-white p-4 rounded mb-6 text-center">
          <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
        </div>
      <?php endif; ?>

      <form action="signup.php" method="POST" class="space-y-6">
        <div>
          <label for="username" class="block text-sm font-semibold mb-2">Username</label>
          <input type="text" id="username" name="username"
            class="w-full px-4 py-3 bg-gray-700 rounded-lg input-focus" required
            value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>">
        </div>

        <div>
          <label for="email" class="block text-sm font-semibold mb-2">Email Address</label>
          <input type="email" id="email" name="email"
            class="w-full px-4 py-3 bg-gray-700 rounded-lg input-focus" required
            value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
        </div>

        <div>
          <label for="password" class="block text-sm font-semibold mb-2">Password</label>
          <input type="password" id="password" name="password"
            class="w-full px-4 py-3 bg-gray-700 rounded-lg input-focus" required
            value="">
        </div>

        <div>
          <label for="confirm_password" class="block text-sm font-semibold mb-2">Confirm Password</label>
          <input type="password" id="confirm_password" name="confirm_password"
            class="w-full px-4 py-3 bg-gray-700 rounded-lg input-focus" required
            value="">
        </div>

        <button type="submit" name="signup"
          class="w-full py-3 bg-gradient-to-r from-purple-600 to-indigo-600 rounded-lg text-lg font-semibold transition-transform transform hover:scale-105 duration-300">
          Sign Up
        </button>
      </form>

      <p class="text-sm text-center text-gray-400 mt-6">Already have an account?
        <a href="login.php" class="text-purple-400 hover:underline">Log in</a>.
      </p>
    </div>
  </section>

  <!-- Footer -->
  <footer class="text-center p-6 text-gray-500 text-sm">
    &copy; <?php echo date('Y'); ?> Gamebyte Store
  </footer>

</body>

</html>
