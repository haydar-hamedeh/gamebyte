<?php
session_start();
include('condb.php'); // Ensure you include your database connection

// Check if the admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: admin_login.php'); // Redirect to login page if not logged in
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_category'])) {
    // Get the category name from the form
    $category_name = mysqli_real_escape_string($conn, $_POST['category_name']);

    // Insert the new category into the database
    $insert_sql = "INSERT INTO category (category_name) VALUES ('$category_name')";

    if ($conn->query($insert_sql) === TRUE) {
        $_SESSION['message'] = "Category added successfully!";
        header('Location: add_category.php');
        exit();
    } else {
        $_SESSION['error'] = "Error adding category: " . $conn->error;
        header('Location: add_category.php');
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Category</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script> <!-- SweetAlert2 -->
</head>
<body class="bg-gray-900 text-white font-sans">

<!-- Navbar -->
<?php include('admin_navbar.php'); ?>

<!-- Main Content -->
<div class="p-10">
    <h2 class="text-3xl font-bold mb-8 text-center">Add New Category</h2>

    <!-- Add Category Form -->
    <form action="add_category.php" method="POST">
        <label for="category_name" class="block mb-2">Category Name:</label>
        <input type="text" name="category_name" id="category_name" required class="bg-gray-800 text-white p-2 rounded w-full mb-4">

        <button type="submit" name="add_category" class="bg-blue-500 hover:bg-blue-600 text-white p-2 rounded">Add Category</button>
    </form>
</div>

<!-- SweetAlert2 for Success or Error -->
<?php if (isset($_SESSION['message'])): ?>
<script>
Swal.fire({
    icon: 'success',
    title: 'Success!',
    text: '<?php echo $_SESSION['message']; ?>',
    confirmButtonColor: '#6366F1'
});
</script>
<?php unset($_SESSION['message']); endif; ?>

<?php if (isset($_SESSION['error'])): ?>
<script>
Swal.fire({
    icon: 'error',
    title: 'Oops...',
    text: '<?php echo $_SESSION['error']; ?>',
    confirmButtonColor: '#EF4444'
});
</script>
<?php unset($_SESSION['error']); endif; ?>

</body>
</html>
