<?php
session_start();
include('condb.php');

// Read JSON body
$data = json_decode(file_get_contents('php://input'), true);

$product_id = intval($data['product_id'] ?? 0);
$quantity = intval($data['quantity'] ?? 1); // Get passed quantity (default 1)

if (!isset($_SESSION['customer_id'])) {
    echo json_encode(['success' => false, 'message' => 'Login required']);
    exit();
}

if ($product_id < 1 || $quantity < 1) {
    echo json_encode(['success' => false, 'message' => 'Invalid product or quantity']);
    exit();
}

// Get product from DB
$sql = "SELECT * FROM products WHERE product_id = $product_id";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    $product = $result->fetch_assoc();

    // If item exists in cart, add quantity instead of overwriting
    if (isset($_SESSION['cart'][$product_id])) {
        $_SESSION['cart'][$product_id]['quantity'] += $quantity;
    } else {
        $_SESSION['cart'][$product_id] = [
            'product_id' => $product_id,
            'product_name' => $product['product_name'],
            'price' => $product['price'],
            'image' => $product['image'],
            'quantity' => $quantity
        ];
    }

    echo json_encode([
        'success' => true,
        'product_name' => $product['product_name'],
        'new_quantity' => $_SESSION['cart'][$product_id]['quantity']
    ]);
} else {
    echo json_encode(['success' => false, 'message' => 'Product not found']);
}
?>
