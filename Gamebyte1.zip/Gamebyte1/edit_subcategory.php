<?php
include('condb.php');
session_start();

// Handle form submission to load selected subcategory
$subcategory = null;
if (isset($_POST['subcategory_id'])) {
    $subcategory_id = intval($_POST['subcategory_id']);
    $sql = "SELECT * FROM subcategory WHERE subcategory_id = $subcategory_id";
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        $subcategory = $result->fetch_assoc();
    } else {
        $_SESSION['error'] = "Subcategory not found.";
        header('Location: edit_subcategory.php');
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Edit Subcategory</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script> <!-- SweetAlert2 -->
</head>
<body class="bg-gray-900 text-white font-sans min-h-screen">
  <?php include('admin_navbar.php'); ?>

  <div class="max-w-lg mx-auto py-12">
    <h2 class="text-3xl font-bold mb-8 text-center">Edit Subcategory</h2>

    <!-- Select Subcategory Form -->
    <form action="edit_subcategory.php" method="POST" class="bg-gray-800 p-6 rounded-lg shadow-lg mb-10">
      <div class="mb-6">
        <label class="block mb-2 text-sm font-bold" for="subcategory_id">Select Subcategory to Edit:</label>
        <select id="subcategory_id" name="subcategory_id" required class="w-full px-4 py-2 text-black rounded-md focus:ring-2 focus:ring-purple-500">
          <option value="">Select a subcategory</option>
          <?php
          $subs = $conn->query("SELECT subcategory_id, subcategory_name FROM subcategory");
          if ($subs->num_rows > 0) {
              while ($row = $subs->fetch_assoc()) {
                  echo "<option value='" . $row['subcategory_id'] . "'>" . htmlspecialchars($row['subcategory_name']) . "</option>";
              }
          } else {
              echo "<option disabled>No subcategories available</option>";
          }
          ?>
        </select>
      </div>

      <button type="submit" class="w-full bg-purple-600 hover:bg-purple-700 py-3 rounded-full text-white font-semibold">
        Select Subcategory
      </button>
    </form>

    <!-- Edit Subcategory Form -->
    <?php if ($subcategory): ?>
    <form action="update_subcategory.php" method="POST" class="bg-gray-800 p-6 rounded-lg shadow-lg">
        <input type="hidden" name="subcategory_id" value="<?php echo htmlspecialchars($subcategory['subcategory_id']); ?>">

        <div class="mb-6">
          <label class="block mb-2 text-sm font-bold" for="subcategory_name">Subcategory Name:</label>
          <input type="text" id="subcategory_name" name="subcategory_name" required value="<?php echo htmlspecialchars($subcategory['subcategory_name']); ?>" class="w-full px-4 py-2 text-black rounded-md focus:ring-2 focus:ring-purple-500">
        </div>

        <button type="submit" class="w-full bg-green-600 hover:bg-green-700 py-3 rounded-full text-white font-semibold">
          Update Subcategory
        </button>
    </form>
    <?php endif; ?>
  </div>

  <!-- SweetAlert2 for success or error -->
  <?php if (isset($_SESSION['message'])): ?>
  <script>
  Swal.fire({
      icon: 'success',
      title: 'Success!',
      text: '<?php echo $_SESSION['message']; ?>',
      confirmButtonColor: '#6366F1'
  });
  </script>
  <?php unset($_SESSION['message']); endif; ?>

  <?php if (isset($_SESSION['error'])): ?>
  <script>
  Swal.fire({
      icon: 'error',
      title: 'Oops...',
      text: '<?php echo $_SESSION['error']; ?>',
      confirmButtonColor: '#EF4444'
  });
  </script>
  <?php unset($_SESSION['error']); endif; ?>
  
</body>
</html>

