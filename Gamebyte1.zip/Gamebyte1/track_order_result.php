<?php
session_start();
include('condb.php');

// Check if the order ID is passed
if (!isset($_GET['order_id'])) {
    echo "No order selected.";
    exit;
}

$order_id = $_GET['order_id'];

// Fetch order details
$sql = "SELECT * FROM orders WHERE order_id = '$order_id'";
$order_result = $conn->query($sql);

if ($order_result->num_rows > 0) {
    $order = $order_result->fetch_assoc();
} else {
    echo "Order not found.";
    exit;
}

// Fetch order items (if any)
$order_items_sql = "SELECT * FROM order_items WHERE order_id = '$order_id'";
$order_items_result = $conn->query($order_items_sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Details</title>
    <link href="styles.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <h1>Order Details</h1>

        <p><strong>Order ID:</strong> <?php echo $order['order_id']; ?></p>
        <p><strong>Order Date:</strong> <?php echo $order['order_date']; ?></p>
        <p><strong>Order Status:</strong> <?php echo $order['status']; ?></p>

        <h2>Items in this Order:</h2>
        <ul>
            <?php
            if ($order_items_result->num_rows > 0) {
                while ($item = $order_items_result->fetch_assoc()) {
                    echo "<li>Product ID: " . $item['product_id'] . " - Quantity: " . $item['quantity'] . "</li>";
                }
            } else {
                echo "<li>No items found in this order.</li>";
            }
            ?>
        </ul>
    </div>
</body>
</html>
