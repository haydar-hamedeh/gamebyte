<?php
session_start();
include('condb.php');

// Check if the admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: admin_login.php');
    exit();
}

// Fetch all categories
$sql = "SELECT * FROM category";
$result = $conn->query($sql);

// Handle category update
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['edit_category'])) {
    $category_id = $_POST['category_id'];
    $category_name = mysqli_real_escape_string($conn, $_POST['category_name']);

    $update_sql = "UPDATE category SET category_name = '$category_name' WHERE category_id = '$category_id'";

    if ($conn->query($update_sql) === TRUE) {
        $_SESSION['message'] = "Category updated successfully!";
        header('Location: edit_category.php?category_id=' . $category_id);
        exit();
    } else {
        $_SESSION['error'] = "Error updating category: " . $conn->error;
        header('Location: edit_category.php?category_id=' . $category_id);
        exit();
    }
}

// Fetch selected category if needed
$category = null;
if (isset($_GET['category_id'])) {
    $category_id = $_GET['category_id'];
    $category_sql = "SELECT * FROM category WHERE category_id = '$category_id'";
    $category_result = $conn->query($category_sql);
    if ($category_result->num_rows > 0) {
        $category = $category_result->fetch_assoc();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Category</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script> <!-- SweetAlert2 -->
</head>
<body class="bg-gray-900 text-white font-sans">

<?php include('admin_navbar.php'); ?>

<div class="p-10">
    <h2 class="text-3xl font-bold mb-8 text-center">Edit Category</h2>

    <!-- Category Selection Form -->
    <form action="edit_category.php" method="GET" class="mb-8">
        <label for="category_id" class="block mb-2">Select Category to Edit:</label>
        <select name="category_id" id="category_id" class="bg-gray-800 text-white p-2 rounded w-full mb-4" required>
            <option value="" disabled selected>Choose a Category</option>
            <?php
            $result2 = $conn->query("SELECT * FROM category");
            while ($row = $result2->fetch_assoc()): ?>
                <option value="<?= $row['category_id']; ?>" <?= (isset($_GET['category_id']) && $_GET['category_id'] == $row['category_id']) ? 'selected' : ''; ?>>
                    <?= htmlspecialchars($row['category_name']); ?>
                </option>
            <?php endwhile; ?>
        </select>
        <button type="submit" class="bg-blue-500 hover:bg-blue-600 text-white p-2 rounded">Edit Selected Category</button>
    </form>

    <?php if ($category): ?>
    <!-- Category Edit Form -->
    <form action="edit_category.php" method="POST">
        <input type="hidden" name="category_id" value="<?= htmlspecialchars($category['category_id']); ?>">

        <label for="category_name" class="block mb-2">Category Name:</label>
        <input type="text" name="category_name" id="category_name"
               value="<?= htmlspecialchars($category['category_name']); ?>"
               class="bg-gray-800 text-white p-2 rounded w-full mb-4" required>

        <button type="submit" name="edit_category" class="bg-blue-500 hover:bg-blue-600 text-white p-2 rounded">
            Update Category
        </button>
    </form>
    <?php endif; ?>
</div>

<!-- SweetAlert2 for Success or Error -->
<?php if (isset($_SESSION['message'])): ?>
<script>
Swal.fire({
    icon: 'success',
    title: 'Success!',
    text: '<?php echo $_SESSION['message']; ?>',
    confirmButtonColor: '#6366F1'
});
</script>
<?php unset($_SESSION['message']); endif; ?>

<?php if (isset($_SESSION['error'])): ?>
<script>
Swal.fire({
    icon: 'error',
    title: 'Oops...',
    text: '<?php echo $_SESSION['error']; ?>',
    confirmButtonColor: '#EF4444'
});
</script>
<?php unset($_SESSION['error']); endif; ?>

</body>
</html>

