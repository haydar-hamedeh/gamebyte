<?php
include('condb.php');

if (isset($_GET['query'])) {
    $search = trim($_GET['query']);
    $search = $conn->real_escape_string($search);

    // Use LIKE '%query%' to allow partial matches anywhere
    $sql = "SELECT product_id, product_name, price, image FROM products WHERE product_name LIKE '%$search%' LIMIT 10";
    $result = $conn->query($sql);

    $products = [];

    while ($row = $result->fetch_assoc()) {
        $products[] = [
            'product_id' => $row['product_id'],
            'name' => $row['product_name'],
            'price' => $row['price'],
            'image' => $row['image']
        ];
    }

    header('Content-Type: application/json');
    echo json_encode($products);
}
?>
