<?php
session_start();
include('condb.php');

// Define the upload directory
$upload_dir = 'uploads/';

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: admin_login.php');
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $product_name = mysqli_real_escape_string($conn, $_POST['product_name']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $category_id = (int) $_POST['category_id'];
    $subcategory_id = (int) $_POST['subcategory_id'];
    $price = (float) $_POST['price'];
    $quantity = (int) $_POST['quantity'];

    if (empty($product_name) || empty($description) || empty($category_id) || empty($subcategory_id) || empty($price) || empty($quantity)) {
        $_SESSION['error'] = "All fields are required!";
    } else {
        if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
            $image = $_FILES['image'];
            $image_name = time() . "_" . basename($image['name']);
            $image_tmp = $image['tmp_name'];

            if (!file_exists($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }

            $image_path = $upload_dir . $image_name;

            if (move_uploaded_file($image_tmp, $image_path)) {
                $stmt = $conn->prepare("INSERT INTO products (product_name, description, category_id, subcategory_id, price, quantity, image) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $stmt->bind_param('ssiidis', $product_name, $description, $category_id, $subcategory_id, $price, $quantity, $image_path);

                if ($stmt->execute()) {
                    $_SESSION['message'] = "Product added successfully!";
                    header('Location: add_product.php');
                    exit();
                } else {
                    $_SESSION['error'] = "Error: " . $stmt->error;
                }
                $stmt->close();
            } else {
                $_SESSION['error'] = "Failed to upload image!";
            }
        } else {
            $_SESSION['error'] = "Image is required!";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Product</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script> <!-- SweetAlert2 -->
</head>
<body class="bg-gray-900 text-white font-sans">
<?php include('admin_navbar.php'); ?>

<div class="max-w-3xl mx-auto mt-20 bg-gray-800 p-6 rounded-lg shadow-lg">
    <h2 class="text-2xl font-bold text-center mb-6">Add New Product</h2>

    <form action="add_product.php" method="POST" enctype="multipart/form-data">
        <div class="mb-4">
            <label for="product_name" class="block text-lg">Product Name:</label>
            <input type="text" name="product_name" id="product_name" class="w-full p-3 rounded-md bg-gray-700 text-white" required>
        </div>

        <div class="mb-4">
            <label for="description" class="block text-lg">Description:</label>
            <textarea name="description" id="description" rows="4" class="w-full p-3 rounded-md bg-gray-700 text-white" required></textarea>
        </div>

        <div class="mb-4">
            <label for="category_id" class="block text-lg">Category:</label>
            <select name="category_id" id="category_id" class="w-full p-3 rounded-md bg-gray-700 text-white" required>
                <option value="" disabled selected>Select a category</option>
                <?php
                $sql = "SELECT * FROM category";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<option value='" . $row['category_id'] . "'>" . htmlspecialchars($row['category_name']) . "</option>";
                    }
                } else {
                    echo "<option value=''>No categories available</option>";
                }
                ?>
            </select>
        </div>

        <div class="mb-4">
            <label for="subcategory_id" class="block text-lg">Subcategory:</label>
            <select name="subcategory_id" id="subcategory_id" class="w-full p-3 rounded-md bg-gray-700 text-white" required>
                <option value="" disabled selected>Select a subcategory</option>
                <!-- Subcategories will load here -->
            </select>
        </div>

        <div class="mb-4">
            <label for="price" class="block text-lg">Price ($):</label>
            <input type="number" step="0.01" name="price" id="price" class="w-full p-3 rounded-md bg-gray-700 text-white" required>
        </div>

        <div class="mb-4">
            <label for="quantity" class="block text-lg">Quantity:</label>
            <input type="number" name="quantity" id="quantity" class="w-full p-3 rounded-md bg-gray-700 text-white" required>
        </div>

        <div class="mb-4">
            <label for="image" class="block text-lg">Product Image:</label>
            <input type="file" name="image" id="image" class="w-full p-3 rounded-md bg-gray-700 text-white" required>
        </div>

        <button type="submit" class="w-full bg-gradient-to-r from-purple-500 to-indigo-600 hover:bg-gradient-to-l px-6 py-3 rounded-full text-sm font-semibold transition duration-300">Add Product</button>
    </form>

    <p class="mt-4 text-center">
        <a href="admin_dashboard.php" class="text-purple-400 hover:text-purple-600">Back to Dashboard</a>
    </p>
</div>

<!-- Load subcategories dynamically -->
<script>
document.getElementById('category_id').addEventListener('change', function() {
    var categoryId = this.value;
    var subcategorySelect = document.getElementById('subcategory_id');
    
    subcategorySelect.innerHTML = '<option value="" disabled selected>Loading...</option>';

    fetch('get_subcategories.php?category_id=' + categoryId)
        .then(response => response.json())
        .then(data => {
            subcategorySelect.innerHTML = '<option value="" disabled selected>Select a subcategory</option>';
            data.forEach(function(subcategory) {
                var option = document.createElement('option');
                option.value = subcategory.subcategory_id;
                option.textContent = subcategory.subcategory_name;
                subcategorySelect.appendChild(option);
            });
        })
        .catch(error => {
            console.error('Error loading subcategories:', error);
            subcategorySelect.innerHTML = '<option value="">Error loading subcategories</option>';
        });
});
</script>

<!-- SweetAlert2 popup if error or success -->
<?php if (isset($_SESSION['message'])): ?>
<script>
  Swal.fire({
    icon: 'success',
    title: 'Success!',
    text: '<?php echo $_SESSION['message']; ?>',
    confirmButtonColor: '#6366F1'
  });
</script>
<?php unset($_SESSION['message']); endif; ?>

<?php if (isset($_SESSION['error'])): ?>
<script>
  Swal.fire({
    icon: 'error',
    title: 'Oops...',
    text: '<?php echo $_SESSION['error']; ?>',
    confirmButtonColor: '#EF4444'
  });
</script>
<?php unset($_SESSION['error']); endif; ?>

</body>
</html>
