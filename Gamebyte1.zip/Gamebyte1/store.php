<?php
include('condb.php');
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Gamebyte Store</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    tailwind.config = {
      theme: {
        extend: {
          animation: {
            fadeIn: 'fadeIn 2s ease-out',
            pulseFast: 'pulse 1.5s infinite',
            bounceIn: 'bounceIn 2s ease-out',
          },
          keyframes: {
            fadeIn: {
              '0%': { opacity: 0 },
              '100%': { opacity: 1 },
            },
            bounceIn: {
              '0%': { transform: 'scale(0)' },
              '100%': { transform: 'scale(1)' },
            }
          }
        }
      }
    }
  </script>
  <!-- Bootstrap CSS for carousel -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-gradient-to-b from-black via-gray-800 to-gray-900 text-white font-sans">

  <!-- Navbar -->
  <?php include('navbar.php'); ?>

  <!-- Carousel Section -->
  <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img src="images/fc25.jpg" class="d-block w-100" alt="Product 1">
      </div>
      <div class="carousel-item">
        <img src="images/gow2.jpg" class="d-block w-100" alt="Product 2">
      </div>
      <div class="carousel-item">
        <img src="images/spiderman2.jpg" class="d-block w-100" alt="Product 3">
      </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
    </button>
  </div>

  <!-- Product Display Section -->
  <div class="container mt-8">
    <h2 class="text-3xl font-bold text-center text-white mb-8">Our Products</h2>
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
      <?php
      $sql = "SELECT * FROM products";
      $result = $conn->query($sql);

      if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
          $image_path = str_replace("\\", "/", $row['image']);

          echo "<div class='bg-gray-800 p-6 rounded-lg shadow-lg'>";
          echo "<img src='" . htmlspecialchars($image_path) . "' alt='" . htmlspecialchars($row['product_name']) . "' class='w-full h-48 object-cover mb-6 rounded-lg'>";
          echo "<h3 class='text-xl font-semibold text-white'>" . htmlspecialchars($row['product_name']) . "</h3>";
          echo "<p class='text-gray-400 mt-2'>" . htmlspecialchars($row['description']) . "</p>";
          echo "<div class='flex justify-between items-center mt-4'>";
          echo "<span class='text-lg text-white'>$" . htmlspecialchars($row['price']) . "</span>";
          echo "<span class='text-sm text-gray-400'>Quantity: " . htmlspecialchars($row['quantity']) . "</span>";
          echo "</div>";

          // Buttons Section
          echo "<div class='flex flex-col space-y-2 mt-4'>";
          if (isset($_SESSION['customer_id'])) {
            echo "<button data-product-id='" . $row['product_id'] . "' class='add-to-cart block bg-gradient-to-r from-purple-500 to-indigo-500 text-white hover:bg-gradient-to-l px-4 py-2 rounded-full text-center text-sm font-semibold transition-all duration-300'>Add to Cart</button>";

          } else {
            echo "<a href='login.php' class='block bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-full text-center text-sm font-semibold transition-all duration-300'>Login to Add to Cart</a>";
          }
          // View Details Button
          echo "<a href='product.php?id=" . urlencode($row['product_id']) . "' class='block bg-gradient-to-r from-green-500 to-teal-500 text-white hover:bg-gradient-to-l px-4 py-2 rounded-full text-center text-sm font-semibold transition-all duration-300'>View Details</a>";
          echo "</div>";

          echo "</div>";
        }
      } else {
        echo "<p class='text-center text-white'>No products available.</p>";
      }
      ?>
    </div>
  </div>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
  document.querySelectorAll('.add-to-cart').forEach(button => {
    button.addEventListener('click', () => {
      const productId = button.getAttribute('data-product-id');

      fetch('add_to_cart.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ product_id: productId })
      })
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          Swal.fire({
            title: 'Product Added!',
            text: `${data.product_name} has been added to your cart.`,
            icon: 'success',
            confirmButtonText: 'OK'
          });
        } else {
          Swal.fire({
            title: 'Oops!',
            text: data.message || 'Could not add product to cart.',
            icon: 'error',
            confirmButtonText: 'OK'
          });
        }
      })
      .catch(() => {
        Swal.fire({
          title: 'Error!',
          text: 'Something went wrong while adding the product.',
          icon: 'error',
          confirmButtonText: 'OK'
        });
      });
    });
  });
</script>


 <!-- Floating Chatbot Button -->
<div id="chatbot-toggle" style="position: fixed; bottom: 30px; right: 30px; background-color: #3b78e6; color: white; border: none; border-radius: 50%; width: 60px; height: 60px; font-size: 24px; display: flex; justify-content: center; align-items: center; cursor: pointer; z-index: 9999;">
  💬
</div>

<!-- Chatbot Window -->
<div id="chatbot-window" class="hidden chatbot-window-style">
  <div class="chatbot-header">GameByte Chatbot</div>
  <div id="chat-content" class="chatbot-content"></div>
  <div class="chatbot-input-area">
    <input type="text" id="user-message" placeholder="Type a message..." class="chatbot-input">
  </div>
</div>

<!-- Chatbot Script -->
<script>
const toggleBtn = document.getElementById('chatbot-toggle');
const chatWindow = document.getElementById('chatbot-window');
const userInput = document.getElementById('user-message');
const chatContent = document.getElementById('chat-content');

toggleBtn.addEventListener('click', () => {
  if (chatWindow.classList.contains('hidden')) {
    chatWindow.classList.remove('hidden');
    setTimeout(() => {
      chatWindow.style.transform = 'scale(1)';
      chatWindow.style.opacity = '1';
    }, 10);
  } else {
    chatWindow.style.transform = 'scale(0)';
    chatWindow.style.opacity = '0';
    setTimeout(() => {
      chatWindow.classList.add('hidden');
    }, 300);
  }
});

userInput.addEventListener('keypress', function(e) {
  if (e.key === 'Enter' && userInput.value.trim() !== '') {
    const userMsg = userInput.value.trim();
    displayMessage(userMsg, 'user');
    userInput.value = '';

    fetch('/GameByte1/chatbot.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: userMsg })
    })
    .then(response => response.json())
    .then(data => {
      const botReply = data.reply;
      displayMessage(botReply, 'bot');
    })
    .catch(error => {
      console.error('Error:', error);
      displayMessage('Sorry, something went wrong.', 'bot');
    });
  }
});

function displayMessage(message, sender) {
  const messageDiv = document.createElement('div');
  messageDiv.classList.add('message');
  messageDiv.classList.add(sender === 'user' ? 'user-message' : 'bot-message');
  messageDiv.innerText = message;
  chatContent.appendChild(messageDiv);
  chatContent.scrollTop = chatContent.scrollHeight;
}
</script>

<!-- Chatbot Styles -->
<style>
/* Full Chatbot Window */
.chatbot-window-style {
  position: fixed;
  bottom: 100px;
  right: 30px;
  width: 320px;
  height: 400px;
  background: #fff;
  border-radius: 15px;
  box-shadow: 0 4px 15px rgba(0,0,0,0.3);
  z-index: 9999;
  flex-direction: column;
  overflow: hidden;
  transform: scale(0);
  opacity: 0;
  transition: all 0.3s ease;
  display: flex;
}

/* Chatbot header */
.chatbot-header {
  background-color: #3b78e6;
  color: white;
  padding: 12px;
  font-weight: bold;
  text-align: center;
  font-size: 18px;
  border-top-left-radius: 15px;
  border-top-right-radius: 15px;
}

/* Messages area */
.chatbot-content {
  flex: 1;
  padding: 10px;
  overflow-y: auto;
  font-size: 14px;
  display: flex;
  flex-direction: column;
  gap: 10px;
  background: #f9f9f9;
}

/* Input area */
.chatbot-input-area {
  padding: 10px;
  border-top: 1px solid #ddd;
  background: #f1f0f0;
}

/* Input field */
.chatbot-input {
  width: 100%;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 10px;
  font-size: 14px;
  outline: none;
  background: white;
  color: black;
}
.chatbot-input:focus {
  border-color: #3b78e6;
}

/* Message Styles */
.message {
  max-width: 70%;
  padding: 8px 12px;
  border-radius: 20px;
  animation: fadeIn 0.5s;
}
.user-message {
  background-color: #3b78e6;
  color: white;
  align-self: flex-end;
  text-align: right;
}
.bot-message {
  background-color: #e5e5ea;
  color: black;
  align-self: flex-start;
  text-align: left;
}

@keyframes fadeIn {
  from { opacity: 0; transform: translateY(10px); }
  to { opacity: 1; transform: translateY(0); }
}
</style>


  <!-- Footer -->
  <footer class="bg-gray-800 text-center py-10 text-gray-400 text-sm mt-20">
    &copy; <?php echo date('Y'); ?> Gamebyte Store. All rights reserved.
  </footer>

  <!-- Bootstrap JS for carousel -->
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>

</body>
</html>
