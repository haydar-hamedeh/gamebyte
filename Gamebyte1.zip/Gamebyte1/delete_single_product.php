<?php
session_start();
include('condb.php');

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

// Check for product_id in query
if (!isset($_GET['product_id'])) {
    $_SESSION['error'] = "Product ID not provided!";
    header('Location: delete_product.php');
    exit();
}

$product_id = (int) $_GET['product_id'];

// Fetch the product to get its image path
$sql = "SELECT * FROM products WHERE product_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $product_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $_SESSION['error'] = "Product not found!";
    header('Location: delete_product.php');
    exit();
}

$product = $result->fetch_assoc();
$image_path = $product['image'];
$stmt->close();

// 🔥 Delete related entries in cart_items and order_items
$conn->query("DELETE FROM cart_items WHERE product_id = $product_id");
$conn->query("DELETE FROM order_items WHERE product_id = $product_id");

// ✅ Now delete the product
$delete_stmt = $conn->prepare("DELETE FROM products WHERE product_id = ?");
$delete_stmt->bind_param("i", $product_id);

if ($delete_stmt->execute()) {
    if (file_exists($image_path)) {
        unlink($image_path); // Delete image from server
    }

    $_SESSION['message'] = "Product deleted successfully!";
} else {
    $_SESSION['error'] = "Error deleting product: " . $conn->error;
}

$delete_stmt->close();

// Redirect back to the product deletion page
header("Location: delete_product.php");
exit();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Confirm Delete</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-900 text-white">

<?php include('admin_navbar.php'); ?>

<div class="max-w-3xl mx-auto mt-16 p-8 bg-gray-800 rounded shadow">
    <h1 class="text-3xl font-bold mb-6 text-red-500">⚠️ Confirm Delete</h1>

    <div class="flex flex-col md:flex-row gap-6">
        <div class="w-full md:w-1/3">
            <img src="<?php echo htmlspecialchars($product['image']); ?>" class="w-full h-auto rounded shadow" alt="Product Image">
        </div>
        <div class="w-full md:w-2/3 space-y-4">
            <h2 class="text-xl font-semibold"><?php echo htmlspecialchars($product['product_name']); ?></h2>
            <p class="text-gray-300"><?php echo htmlspecialchars($product['description']); ?></p>
            <p><strong>Price:</strong> $<?php echo number_format($product['price'], 2); ?></p>
            <p><strong>Quantity:</strong> <?php echo $product['quantity']; ?></p>
        </div>
    </div>

    <form method="POST" class="mt-8 text-center">
        <button type="submit" name="confirm_delete"
            class="bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-full font-semibold transition">
            Yes, Delete Product
        </button>
        <a href="delete_product.php"
           class="ml-4 inline-block px-6 py-3 rounded-full border border-gray-500 text-gray-300 hover:bg-gray-700 transition">
            Cancel
        </a>
    </form>
</div>
<!-- Show SweetAlert2 popup based on the result -->
<?php if ($delete_success): ?>
<script>
Swal.fire({
  icon: 'success',
  title: 'Deleted!',
  text: 'Product "<?php echo htmlspecialchars($product['product_name']); ?>" was deleted successfully!',
  confirmButtonColor: '#6366F1'
}).then(() => {
  window.location.href = 'delete_product.php';
});
</script>
<?php elseif (isset($_SESSION['error'])): ?>
<script>
Swal.fire({
  icon: 'error',
  title: 'Error',
  text: '<?php echo $_SESSION['error']; ?>',
  confirmButtonColor: '#EF4444'
}).then(() => {
  window.location.href = 'delete_product.php';
});
</script>
<?php unset($_SESSION['error']); endif; ?>

</body>
</html>
