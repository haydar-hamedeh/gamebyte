<?php
// Start the session
session_start();

// Clear all session variables
session_unset();

// Destroy the session
session_destroy();

// Delete the session cookie if it exists
if (isset($_COOKIE[session_name()])) {
    setcookie(session_name(), '', time() - 3600, '/');
}

// Check if the session is destroyed properly
if (session_status() == PHP_SESSION_NONE) {
    // If session is successfully destroyed, redirect to login page
    header('Location: admin_login.php');
    exit(); // Ensure no further code is executed after redirection
} else {
    // If for any reason the session is not destroyed, force a redirect
    echo "Error: Session could not be destroyed. Redirecting to login page.";
    header('Location: admin_login.php');
    exit();
}
?>
