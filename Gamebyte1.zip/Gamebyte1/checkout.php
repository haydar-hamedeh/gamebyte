<?php
include('condb.php');
session_start();

// Check if customer is logged in
if (!isset($_SESSION['customer_email']) || empty($_SESSION['customer_email'])) {
    header("Location: login.php");
    exit();
}

$customer_email = $_SESSION['customer_email'];
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $shipping_address = $_POST['shipping_address'];
    $phone_number = $_POST['phone_number'];
    $payment_method = $_POST['payment_method'];

    $visa_card_number = isset($_POST['visa_card_number']) ? $_POST['visa_card_number'] : '';
    $visa_card_expiry = isset($_POST['visa_card_expiry']) ? $_POST['visa_card_expiry'] : '';
    $visa_card_cvc = isset($_POST['visa_card_cvc']) ? $_POST['visa_card_cvc'] : '';

    $total_price = 0;
    $valid_order = true;

    if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
        foreach ($_SESSION['cart'] as $product_id => $item) {
            $quantity = $item['quantity'];
            $sql = "SELECT * FROM products WHERE product_id = $product_id";
            $product_result = $conn->query($sql);

            if ($product_result->num_rows == 0) {
                $valid_order = false;
                $error_message = "Error: Product with ID $product_id does not exist.";
                break;
            }

            $product = $product_result->fetch_assoc();

            if ($quantity > $product['quantity']) {
                $valid_order = false;
                $error_message = "Error: Not enough stock for " . htmlspecialchars($product['product_name']) . ". Available: " . $product['quantity'] . ", Requested: " . $quantity . ".";
                break;
            }

            $total_price += $product['price'] * $quantity;
        }

        if ($valid_order) {
            $email_safe = mysqli_real_escape_string($conn, $customer_email);
            $sql = "SELECT customer_id FROM customer WHERE email = '$email_safe'";
            $result = $conn->query($sql);

            if ($result && $result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $customer_id = $row['customer_id'];

                $order_sql = "INSERT INTO orders (customer_id, total_price, shipping_address, phone_number, payment_method) 
                              VALUES ($customer_id, $total_price, '$shipping_address', '$phone_number', '$payment_method')";

                if ($conn->query($order_sql)) {
                    $order_id = $conn->insert_id;

                    foreach ($_SESSION['cart'] as $product_id => $item) {
                        $quantity = $item['quantity'];

                        $order_item_sql = "INSERT INTO order_items (order_id, product_id, quantity) 
                                           VALUES ($order_id, $product_id, $quantity)";
                        $conn->query($order_item_sql);

                        $update_quantity_sql = "UPDATE products 
                                                SET quantity = quantity - $quantity 
                                                WHERE product_id = $product_id";
                        $conn->query($update_quantity_sql);
                    }

                    unset($_SESSION['cart']);
                    header("Location: track_order.php?order_id=$order_id");
                    exit();
                } else {
                    $error_message = "Order error: " . $conn->error;
                }
            } else {
                $error_message = "Customer not found.";
            }
        }
    } else {
        $error_message = "Your cart is empty.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Checkout</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    function toggleVisaCardFields() {
      const paymentMethod = document.getElementById('payment_method').value;
      const visaCardFields = document.getElementById('visa-card-fields');
      if (paymentMethod === 'visa_card') {
          visaCardFields.style.display = 'block';
      } else {
          visaCardFields.style.display = 'none';
      }
    }
  </script>
</head>

<body class="bg-gradient-to-b from-black via-gray-800 to-gray-900 text-white font-sans">

<?php include('navbar.php'); ?>

<?php if (!empty($error_message)) : ?>
  <div class="bg-red-500 text-white text-center p-4">
    <?php echo $error_message; ?>
  </div>
<?php endif; ?>

<section id="checkout-heading" class="py-20 text-center">
  <h2 class="text-5xl font-extrabold text-white mb-10">Checkout</h2>
</section>

<section id="checkout-form" class="py-20 px-4">
  <div class="max-w-lg mx-auto bg-gray-800 p-6 rounded-lg shadow-xl">
    <h3 class="text-3xl font-semibold text-white mb-6">Customer Information</h3>
    <form action="checkout.php" method="POST">
      <div class="mb-4">
        <label for="email" class="block text-lg text-white">Email</label>
        <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($customer_email); ?>" class="w-full p-2 mt-2 bg-gray-700 text-white rounded" readonly>
      </div>
      <div class="mb-4">
        <label for="phone_number" class="block text-lg text-white">Phone Number</label>
        <input type="text" id="phone_number" name="phone_number" class="w-full p-2 mt-2 bg-gray-700 text-white rounded" required>
      </div>
      <div class="mb-4">
        <label for="shipping_address" class="block text-lg text-white">Shipping Address</label>
        <input type="text" id="shipping_address" name="shipping_address" class="w-full p-2 mt-2 bg-gray-700 text-white rounded" required>
      </div>
      <div class="mb-4">
        <label for="payment_method" class="block text-lg text-white">Payment Method</label>
        <select id="payment_method" name="payment_method" class="w-full p-2 mt-2 bg-gray-700 text-white rounded" onchange="toggleVisaCardFields()" required>
          <option value="cash_on_delivery">Cash on Delivery</option>
          <option value="visa_card">Visa Card</option>
        </select>
      </div>

      <div id="visa-card-fields" class="mb-4" style="display:none;">
        <label for="visa_card_number" class="block text-lg text-white">Visa Card Number</label>
        <input type="text" id="visa_card_number" name="visa_card_number" class="w-full p-2 mt-2 bg-gray-700 text-white rounded">
        <label for="visa_card_expiry" class="block text-lg text-white mt-4">Visa Card Expiry Date</label>
        <input type="text" id="visa_card_expiry" name="visa_card_expiry" class="w-full p-2 mt-2 bg-gray-700 text-white rounded">
        <label for="visa_card_cvc" class="block text-lg text-white mt-4">Visa Card CVC</label>
        <input type="text" id="visa_card_cvc" name="visa_card_cvc" class="w-full p-2 mt-2 bg-gray-700 text-white rounded">
      </div>

      <button type="submit" class="bg-gradient-to-r from-purple-500 to-indigo-500 text-white hover:bg-gradient-to-l px-6 py-3 rounded-full text-sm font-semibold transition-all duration-300 mt-4 inline-block">
        Place Order
      </button>
    </form>
  </div>
</section>

<!-- Cart Summary -->
<section id="cart-summary" class="py-20 px-4">
  <div class="max-w-lg mx-auto bg-gray-800 p-6 rounded-lg shadow-xl">
    <h3 class="text-3xl font-semibold text-white mb-6">Cart Summary</h3>
    <?php if (!empty($_SESSION['cart'])) { ?>
      <ul class="text-white">
        <?php
        $total = 0;
        foreach ($_SESSION['cart'] as $product_id => $item) {
          $quantity = $item['quantity'];
          $product_name = $item['product_name'];
          $price = $item['price'];

          $total_price = $price * $quantity;
          $total += $total_price;
        ?>
          <li class="mb-4">
            <span class="font-semibold"><?php echo htmlspecialchars($product_name); ?></span> x <?php echo $quantity; ?> - $<?php echo number_format($total_price, 2); ?>
          </li>
        <?php } ?>
      </ul>
      <div class="text-right mt-6">
        <h4 class="font-semibold text-xl text-white">Total: $<?php echo number_format($total, 2); ?></h4>
      </div>
    <?php } else { ?>
      <p class="text-white text-center">Your cart is empty.</p>
    <?php } ?>
  </div>
</section>

</body>
</html>
