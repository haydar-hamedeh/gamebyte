<?php
session_start();
include('condb.php'); // Include your database connection

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $subcategory_id = intval($_POST['subcategory_id']);
    $subcategory_name = mysqli_real_escape_string($conn, $_POST['subcategory_name']);

    if (!empty($subcategory_name) && $subcategory_id > 0) {
        $update_sql = "UPDATE subcategory SET subcategory_name = '$subcategory_name' WHERE subcategory_id = $subcategory_id";

        if ($conn->query($update_sql) === TRUE) {
            $_SESSION['message'] = "Subcategory updated successfully!";
            header('Location: edit_subcategory.php');
            exit();
        } else {
            $_SESSION['error'] = "Error updating subcategory: " . $conn->error;
            header('Location: edit_subcategory.php');
            exit();
        }
    } else {
        $_SESSION['error'] = "Invalid subcategory data.";
        header('Location: edit_subcategory.php');
        exit();
    }
} else {
    $_SESSION['error'] = "Invalid request.";
    header('Location: edit_subcategory.php');
    exit();
}
?>
